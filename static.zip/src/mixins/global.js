import Vue from 'vue'

export default {
  methods: {

    _findJaarvorderingsplannenActivityRecord(key) {
      if (key && key.length > 0) {
        if (sessionStorage.getItem('VUE_CUSTOM_CURRICULA') !== null) {
          var sessionConfigCustomCurricula = JSON.parse(sessionStorage.getItem('VUE_CUSTOM_CURRICULA'))
          for (var x = 0; x < sessionConfigCustomCurricula.length; x++) {
            var customCurricula = sessionConfigCustomCurricula[x]
            for (var y = 0; y < customCurricula.Activiteiten.length; y++) {
              var llinkidFlattedActivity = customCurricula.Activiteiten[y]
              if (llinkidFlattedActivity.ID === key) {
                return llinkidFlattedActivity
              }
            }
          }
        }
      }
    },

    _recHasChanged(origRec, rec, ignoreItems) {
      if (ignoreItems !== undefined && ignoreItems.length > 0) {
        for (let x = 0; x < ignoreItems.length; x++) {
          let ignoreItem = ignoreItems[x]
          delete origRec[ignoreItem]
          if ((!this._isEmpty(rec)) && (!this._isEmpty(ignoreItem))) {
            delete rec[ignoreItem]
          }
        }
      }
      if (_.isEqual(origRec, rec)) {
        return false
      } else {
        return true
      }
    },

    _selectieAllesNiets(list, trueFalse, childrenField, enableEvenIfDisabled) {
      for (let y1 = 0; y1 < list.length; y1++) {
        let rec = list[y1]
        if (enableEvenIfDisabled) {
          rec.Disabled = false
        }
        if (!rec.Disabled) {
          rec.Actief = trueFalse
          if (childrenField !== undefined && childrenField !== null) {
            let childArray = rec[childrenField]
            for (let x = 0; x < childArray.length; x++) {
              let childRec = childArray[x]
              if (!childRec.Disabled) {
                childRec.Actief = rec.Actief
              }
            }
          }
          Vue.set(list, y1, rec)
        }
      }
      this.$forceUpdate()
    },

    _selectEnigeRecord(list, actiefRec, primaryKeyNotID) {
      for (let y1 = 0; y1 < list.length; y1++) {
        let rec = list[y1]
        if (!(_.isEmpty(primaryKeyNotID))) {
          if (rec[primaryKeyNotID] === actiefRec[primaryKeyNotID]) {
            rec.Actief = true
          } else {
            rec.Actief = false
          }
        } else {
          if (rec.ID === actiefRec.ID) {
            rec.Actief = true
          } else {
            rec.Actief = false
          }
        }

        Vue.set(list, y1, rec)
      }
      this.$forceUpdate()
    },

    _getEnigeActieveRecord(list) {
      for (let y1 = 0; y1 < list.length; y1++) {
        let rec = list[y1]
        if (rec.Actief) {
          return rec
        }
      }
    },

    _getAlleActieveRecord(list) {
      var actieve = []
      for (let y1 = 0; y1 < list.length; y1++) {
        let rec = list[y1]
        if (rec.Actief) {
          actieve.push(rec)
        }
      }
      return actieve
    },

    _selectieRecord(list, index, rec, childrenField, parentOfChild, oneChildActiveIsParentActive, specialDisableField) {
      if (rec.Disabled || specialDisableField) {
        console.log('niets doen')
      } else {
        if (rec.Actief === undefined) {
          rec.Actief = true
        } else {
          rec.Actief = !rec.Actief
        }
        if (childrenField !== undefined && childrenField !== null) {
          let childArray = rec[childrenField]
          for (let x = 0; x < childArray.length; x++) {
            let childRec = childArray[x]
            if (!childRec.Disabled) {
              childRec.Actief = rec.Actief
            }
          }
        }
        if (parentOfChild !== undefined && parentOfChild !== null) {
          let noActiveChild = true
          let allChildsActive = true
          for (let y = 0; y < list.length; y++) {
            let listItem = list[y]
            if (listItem.Actief) {
              noActiveChild = false
            } else {
              allChildsActive = false
            }
          }
          if (noActiveChild || !allChildsActive) {
            parentOfChild.Actief = false
          }
          if (allChildsActive) {
            parentOfChild.Actief = true
          }
          if (oneChildActiveIsParentActive) {
            parentOfChild.Actief = true
          }
        }
        Vue.set(list, index, rec)
      }
    },

    _selectieSiblingChildsRecordThroughParentRec(list, indexInList, parent, indexParent, selectedChildecord, selectedChildecordIndex, childField,
      checkField) {
      if (selectedChildecord.Disabled) {
        console.log('niets doen')
      } else {
        var inverseValue = !selectedChildecord.Actief
        var parentItem = list[indexInList]
        for (var c = 0; c < parentItem.Records.length; c++) {
          var childRec = parentItem.Records[c]
          var array = childRec[childField]
          for (var x = 0; x < array.length; x++) {
            var arrayRec = array[x]
            if (arrayRec[checkField] === selectedChildecord[checkField]) {
              if (!arrayRec.AlreadyExists) {
                arrayRec.Actief = inverseValue
              }
            }
          }
          console.log('test')

        }
        Vue.set(list, indexInList, parentItem)
      }
    },

    _checkSelectieGemaakt(list, childrenField) {
      for (let y1 = 0; y1 < list.length; y1++) {
        let rec = list[y1]
        if (rec.Actief) {
          return true
        }
        if (childrenField !== undefined && childrenField !== null) {
          let childArray = rec[childrenField]
          for (let x = 0; x < childArray.length; x++) {
            let childRec = childArray[x]
            if (childRec.Actief) {
              return true
            }
          }
        }
      }
      return false
    },

    _arrayVanVeld(list, field, filterBoolean) {
      let fieldArray = []
      for (let y1 = 0; y1 < list.length; y1++) {
        let rec = list[y1]
        if (filterBoolean === undefined || rec[filterBoolean]) {
          fieldArray.push(rec[field])
        }
      }
      return fieldArray
    },

    _stringVanVeld(list, field, seperator, filterBoolean) {
      let fieldArray = this._arrayVanVeld(list, field, filterBoolean)
      if (seperator !== undefined) {
        return fieldArray.join(seperator)
      } else {
        return fieldArray.join()
      }
    },

    _console() { // if development -> then show
      console.log(...arguments)
    }
  }
}
