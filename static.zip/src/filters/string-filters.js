import Vue from 'vue'
import strOperations from '@/mixins/string-operations.js'
Vue.filter('capitalizeFirstLetters', (value) => {
  return strOperations.methods._capitalizeFirstLetters(value)
})
Vue.filter('capitalizeOnlyFirstLetters', (value) => {
  return strOperations.methods._capitalizeFirstLetter(value)
})
Vue.filter('removeSpecialChars', (value) => {
  return strOperations.methods._removeSpecialChars(value)
})
