/* Load Vue Modules */
import Vue from 'vue'
import Router from 'vue-router'
/* Store import for auto-logout */
import store from '../store'
import * as globalTypes from '../store/mutation-types.js'
/* Load Global Components */
import Home from '@/components/screens/home/home.vue'
import Search from '@/components/screens/search/search.vue'
import Add from '@/components/screens/add/add.vue'
import Chat from '@/components/screens/chat/chat.vue'
import Profile from '@/components/screens/profile/profile.vue'
import Notificaties from '@/components/screens/notificaties/notificaties.vue'
import SplashScreen from '@/components/screens/splash-screen/splash-screen.vue'
import AdTab from '@/components/screens/ad-tab/ad-tab.vue'
import AdTabForm from '@/components/screens/ad-tab-form/ad-tab-form.vue'
import Login from '@/components/screens/login/login.vue'
import Register from '@/components/screens/register/register.vue'
import showIcons from '@/components/utils/_show_icons/_show_icons.vue'
import dropdownPage from '@/components/utils/dropdown-page/dropdown-page.vue'
import myMessages from '@/components/screens/my-messages/my-messages.vue'
import UpdateProfile from '@/components/screens/update-profile/update-profile.vue'
import selectTag from '@/components/screens/select-tag/select-tag.vue'
import postList from '@/components/screens/post-list/post-list.vue'
import settings from '@/components/screens/settings/settings.vue'
import question from '@/components/screens/question/question.vue'
import postContainer from '@/components/screens/post-container/post-container.vue'
/* Load Agenda Components */

Vue.use(Router)

const router = new Router({
  mode: 'hash',
  routes: [
    /* Algemeen Schermen */
    {
      path: '/',
      name: 'splash',
      component: SplashScreen,
      meta: {
        backButtonAvailable: false,
        moduleName: 'SplashScreen',
        firstPage: true
      }
    },
    {
      path: '/login',
      name: 'login',
      component: Login,
      meta: {
        backButtonAvailable: false,
        moduleName: 'Login',
        firstPage: true
      }
    },
    {
      path: '/register',
      name: 'register',
      component: Register,
      meta: {
        backButtonAvailable: false,
        moduleName: 'Register',
        firstPage: true
      }
    },
    {
      path: '/home',
      name: 'home',
      component: Home,
      meta: {
        backButtonAvailable: false,
        moduleName: 'General',
        firstPage: true
      }
      /* ,
            beforeEnter: (to, from, next) => {
              // if not first opening && if not logged out
              if (from.name !== null && from.meta.moduleName !== 'Connection' && store.state.userInfo.loggedInConnectionObject !== null) {
                store.commit(globalTypes.LOGGED_OUT_ONCE)
                store.dispatch('logout')
              }
              next()
            } */
    },
    // {
    //   path: '/login',
    //   name: 'Login Page',
    //   component: Login
    // },
    {
      path: '/_show_icons',
      name: 'Show Icons',
      component: showIcons,
      meta: {
        backButtonAvailable: false,
        moduleName: 'General',
        firstPage: false
      }
    },
    {
      path: '/search',
      name: 'search',
      component: Search,
      meta: {
        backButtonAvailable: false,
        moduleName: 'Search',
        firstPage: true
      }
    },
    {
      path: '/ad-tab-form',
      name: 'adtabform',
      component: AdTabForm,
      meta: {
        backButtonAvailable: true,
        specialButtonAvailable: false,
        moduleName: 'Ad',
        firstPage: false
      }
    },
    {
      path: '/ad-tab',
      name: 'adtab',
      component: AdTab,
      meta: {
        backButtonAvailable: false,
        specialButtonAvailable: true,
        moduleName: 'Add',
        firstPage: true
      }
    },
    {
      path: '/add',
      name: 'add',
      component: Add,
      meta: {
        backButtonAvailable: false,
        specialButtonAvailable: true,
        moduleName: 'Add',
        firstPage: true
      }
    },
    {
      path: '/profile/:profileID/',
      name: 'profile',
      component: Profile,
      meta: {
        backButtonAvailable: true,
        specialButtonAvailable: true,
        moduleName: 'Profile',
        firstPage: true
      }
    },
    {
      path: '/postcontainer/:postID',
      name: 'postcontainer',
      component: postContainer,
      meta: {
        backButtonAvailable: true,
        specialButtonAvailable: false,
        moduleName: 'postContainer',
        firstPage: true
      }
    },
    {
      path: '/my-messages',
      name: 'mymessages',
      component: myMessages,
      meta: {
        backButtonAvailable: true,
        moduleName: 'Messages',
        firstPage: true,
        showHeaderTitle: true
      }
    },
    {
      path: '/notifications',
      name: 'notifications',
      component: Notificaties,
      meta: {
        backButtonAvailable: true,
        moduleName: 'General',
        firstPage: true,
        showHeaderTitle: true
      }
    },
    {
      path: '/chat',
      name: 'chat',
      component: Chat,
      meta: {
        backButtonAvailable: true,
        moduleName: 'Messages',
        firstPage: false,
        showHeaderTitle: true
      }
    },
    {
      path: '/update-profile',
      name: 'updateprofile',
      component: UpdateProfile,
      meta: {
        backButtonAvailable: true,
        moduleName: 'Profile',
        firstPage: true
      }
    },
    {
      path: '/question',
      name: 'question',
      component: question,
      meta: {
        backButtonAvailable: true,
        moduleName: 'Profile',
        firstPage: true
      }
    },
    {
      path: '/settings',
      name: 'settings',
      component: settings,
      meta: {
        backButtonAvailable: true,
        moduleName: 'settings',
        firstPage: true
      }
    },
    {
      path: '/post-list',
      name: 'postList',
      component: postList,
      meta: {
        backButtonAvailable: true,
        moduleName: 'PostList',
        firstPage: true
      }
    },
    {
      path: '/select-tag',
      name: 'selectTag',
      component: selectTag,
      meta: {
        backButtonAvailable: true,
        moduleName: 'Algemeen',
        firstPage: false
      }
    },
    /* Algemeen dropdown pagina */
    {
      path: '/maak-een-keuze',
      name: 'dropdown Page',
      component: dropdownPage,
      meta: {
        backButtonAvailable: true,
        moduleName: 'General',
        firstPage: false
      }
    }
  ]
})

router.beforeEach((to, from, next) => {
  // console.log('---------------------------------------------------- Owwwwwwwwwwwwww')
  // console.log(from)
  // console.log(to)

  // console.log(dezeStore)
  // if (to.path === '/landing-page') {

  // }
  next()
})

export default router