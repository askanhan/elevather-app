<template src="./_show_icons.html"></template>
<script src="./_show_icons.js"></script>
<style src="./_show_icons.css" scoped></style>
