<template src="./kalender.html"></template>
<script src="./kalender.js"></script>

