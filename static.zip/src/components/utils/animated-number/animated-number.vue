<template src="./animated-number.html"></template>
<script src="./animated-number.js"></script>
