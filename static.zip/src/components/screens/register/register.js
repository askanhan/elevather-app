import { TYPE } from "vue-toastification";
import * as globalTypes from '@/store/mutation-types'
import Footer from '@/components/complementarities/footer/footer.vue'
import icons from '@/mixins/icons.js'
import basicOperations from '@/mixins/basic-operations'
import * as mutationTypes from '@/store/mutation-types.js'
import UIText from '@/mixins/ui-text.js'
//  const basicOperations = require('@/mixins/basic-operations.js')

import Vue from 'vue'
export default {
  name: 'Register',
  components: {
    Footer
  },
  mixins: [basicOperations, icons, UIText],
  data() {
    return {
      onceFilledInUsername: false,
      onceFilledInEmail: false,
      onceFilledInPwd: false,
      onceFilledInPwd2: false,
      username: '',
      password: '',
      password2: '',
      email: '',
      usernameError: 'Lutfen kullanici adi girin',
      passwordError: 'Lutfen sifrenizi girin',
      password2Error: 'Lutfen sifrenizi girin',
      mailError: 'Lutfen mail adresi girin'
    }
  },

  computed: { // cached and changed only if one of its dependencies is changed
  },
  created() {
  },
  mounted() { },
  methods: {
    unChanged() {
    },
    validateEmail(email) {
      // eslint-disable-next-line 
      let re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
      return re.test(String(email).toLowerCase())
    },
    goToLogin() {
      this.$router.push({
        name: 'login'
      })
    },
    showError(err) {
      this.$toast(err, {
        type: TYPE.ERROR
      })
    },
    createAccount() {
      if (this.usernameError.length > 0) {
        this.showError(this.usernameError)
      } else if (this.mailError.length > 0) {
        this.showError(this.mailError)
      } else if (this.passwordError.length > 0) {
        this.showError(this.passwordError)
      } else if (this.password2Error.length > 0) {
        this.showError(this.password2Error)
      } else {//OK
        console.log('ok')
        this.$store.dispatch({
          type: 'register',
          username: this.username,
          mail: this.email,
          password: this.password,
          successCB: (res) => {
            this.$router.push({
              name: 'home'
            })
          }
        })
      }
    }
  },
  watch: {
    username(to) {
      this.onceFilledInUsername = true
      if (this.username && this.username.length > 2) {
        this.usernameError = ''
      } else {
        this.usernameError = 'Kullanici adiniz en az 3 haneli olmalidir'
      }
    },
    email(to) {
      this.onceFilledInEmail = true
      if (this.email && this.email.length > 2 && this.validateEmail(this.email)) {
        this.mailError = ''
      } else {
        this.mailError = 'Not valid mail address'
      }
    },
    password(to) {
      this.onceFilledInPwd = true
      if (this.password && this.password.length > 5) {
        this.passwordError = ''
      } else {
        this.passwordError = 'Sifreniz en az 6 haneli olmali'
      }
    },
    password2(to) {
      this.onceFilledInPwd2 = true
      if (this.password2 && this.password2 === this.password) {
        this.password2Error = ''
      } else {
        this.password2Error = 'Sifreleriniz birbiriyle uyusmuyor'
      }
    },
  }
}