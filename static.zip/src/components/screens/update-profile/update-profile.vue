<template src="./update-profile.html"></template>
<script src="./update-profile.js"></script>
<style src="./update-profile.css" scoped></style>
