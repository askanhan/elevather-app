import icons from '@/mixins/icons.js'
import basicOperations from '@/mixins/basic-operations'
import UIText from '@/mixins/ui-text.js'
import moment from 'moment'
export default {
  name: 'Settings',
  mixins: [basicOperations, icons, UIText],
  data() {
    return {
      iwantnotification: 'yes'
    }
  },

  components: {
  },

  computed: {
    lang() {
      return this.$store.state.lang
    }
  },
  created() {
    if(localStorage.iwantnotification){
      this.iwantnotification = localStorage.iwantnotification
    }
  },
  mounted() {
  },
  methods: {
    openLangModal() {
      this.$modal.show('threedot')
    },
    setNotificationSetting() {
      this.iwantnotification = this.iwantnotification === 'yes' ? 'no' : 'yes'
      localStorage.iwantnotification = this.iwantnotification
      window.plugins.OneSignal.sendTags({
        sendnotification: this.iwantnotification
      })
    },
    logout() {
      this.$fire({
        title: this.UIText.areyousure[this.lang],
        showConfirmButton: true,
        showCancelButton: true,
        confirmButtonText: this.UIText.logout[this.lang],
        cancelButtonText: this.UIText.cancel[this.lang],
      }).then(r => {
        console.log(r)
        if (r.value) {
          localforage.clear()
          this.$store.commit('LOGGED_OUT')
          this.$store.commit('SET_STATE_TO_INITIAL_VALUES')
          this.$router.push({
            name: 'splash'
          })
        }
      })
    }
  },
  watch: {}
}