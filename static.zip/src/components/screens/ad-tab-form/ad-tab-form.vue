<template src="./ad-tab-form.html"></template>
<script src="./ad-tab-form.js"></script>
<style src="./ad-tab-form.css" scoped></style>
