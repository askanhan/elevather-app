import * as globalTypes from '@/store/mutation-types'
import icons from '@/mixins/icons.js'
import Post from '@/components/complementarities/post/post.vue'
import basicOperations from '@/mixins/basic-operations'
import * as mutationTypes from '@/store/mutation-types.js'
import UIText from '@/mixins/ui-text.js'
import Footer from '@/components/complementarities/footer/footer.vue'
import Treeselect from '@riophae/vue-treeselect'
//  const basicOperations = require('@/mixins/basic-operations.js')

import Vue from 'vue'
export default {
  name: 'AdTab',
  mixins: [basicOperations, icons, UIText],
  components: {
    Post,
    Footer,
    Treeselect
  },
  data() {
    return {
      selectedProvince: 2,
      periodType: {
        tr: [{
          id: 0,
          label: 'Günlük',
          secondary: 'gün'
        }, {
          id: 1,
          label: 'Haftalik',
          secondary: 'hafta'
        }, {
          id: 2,
          label: 'Aylik',
          secondary: 'ay'
        }],
        nl: [{
          id: 0,
          label: 'Dag',
          secondary: 'dagen'
        }, {
          id: 1,
          label: 'Week',
          secondary: 'weken'
        }, {
          id: 2,
          label: 'Maand',
          secondary: 'maanden'
        }],
        fr: [{
          id: 0,
          label: 'Jour',
          secondary: 'jours'
        }, {
          id: 1,
          label: 'Semaine',
          secondary: 'semaines'
        }, {
          id: 2,
          label: 'Mois',
          secondary: 'mois'
        }],
      },
      selectedPeriodType: '',
      howlong: 1,
      slogan1: '',
      slogan2: '',
      phoneNumber: '',
      postName: '',
    }
  },

  computed: {
    provinces() {
      return _.sortBy(this.$store.state.provinces, (a) => {
        if (a.pr_id === this.connectedProvince) {
          return 0
        }
        let sortExtra = this.ads.filter(ad => ad.ad_show === 1 && ad.fk_province == a.pr_id).length > 0 ? 30 : 0
        return a.pr_sort - sortExtra

        // return this.ads.filter(ad => ad.ad_show === 1 && ad.fk_province == pr.pr_id).length>0
      })
    },
    ads() {
      return this.$store.state.adTab
    },
  },
  created() {
    this.selectedPeriodType = this.periodType[this.lang][1].id
    this.$store.commit('SET_SPECIAL_BUTTON', {
      label: this.UIText.goForAd[this.lang],
      toBeExecutedFunction: () => {
        this.openAdDialog()
      }
    })
    if (this.connectedProvince === -1) {
      this._detectLocation((connectedProvince) => {
        console.log(connectedProvince)
        this.selectedProvince = connectedProvince
        this.$store.commit('SET_CONNECTED_PROVINCE', connectedProvince)
      })
    } else {
      this.selectedProvince = this.connectedProvince
    }
  },
  mounted() {
  },
  methods: {
    postForm() {
      this.$store.dispatch({
        type: 'postQuestion',
        qu_type: 91,
        message: `selectedProvince: ${this.selectedProvince}, selectedPeriodType: ${this.selectedPeriodType}, howlong: ${this.howlong}, slogan1: ${this.slogan1}, slogan2: ${this.slogan2}, post: ${this.postName}, tel: ${this.phoneNumber}`,
        successCallback: () => {

          this.$fire({
            title: this.UIText.adGivenHeader[this.lang],
            text: this.UIText.adGiven[this.lang],
            confirmButtonText: this.UIText.okay[this.lang]
          }).then(r => {
            this.$router.go(-1)
            this.$toast(this.UIText.postIsSent[this.lang])
          });
        }
      })
    },
    totalAmount() {
      let multiply = 1
      if (this.selectedPeriodType === 0) {
        multiply = 10
      }
      if (this.selectedPeriodType === 1) {
        multiply = 50
      }
      if (this.selectedPeriodType === 2) {
        multiply = 150
      }
      return multiply * this.howlong
    },
    goToProfile(ppID) {
      this.$router.push({
        name: 'profile',
        params: {
          profileID: ppID
        }
      })
    },
    amIFollowing() {
      if (this.$store.state.profile.Followings && this.$store.state.profile.Followings.length > 0) {
        return this.$store.state.profile.Followings.split(',').filter(pid => pid == this.selectedAdsProfile.p_id).length > 0
      }
      return false
    },
    follow(followWithNotification) {
      if (this.amIFollowing()) {
        this.$store.dispatch({
          type: 'unfollow',
          following: this.selectedAdsProfile.p_id,
          successCB: (res) => {

          }
        })
      } else {
        this.$store.dispatch({
          type: 'follow',
          followed: this.$store.state.user.fk_profile,
          following: this.selectedAdsProfile.p_id,
          followWithNotification: 1,
          successCB: (res) => {
            this.$store.dispatch({
              type: 'createNotification',
              noti_type: 3,
              fk_for_profile: this.selectedAdsProfile.fk_profile
            })
          }
        })
      }
    },
    openAdDialog() {
      this.$fire({
        title: this.UIText.giveAddTitle[this.lang],
        // text: 'selam',
        confirmButtonText: this.UIText.confirm[this.lang]
      }).then(r => {
        console.log(r.value)
        if (r.value) {
          this.$store.dispatch({
            type: 'postQuestion',
            qu_type: 2,
            message: 'reklam vermek istiyorum',
            successCallback: () => {
              this.$toast(this.UIText.postIsSent[this.lang])
            }
          })
        }
      });
    },
    selectTag() {

    },
    getPostByID(id) {
      return this.$store.state.allPosts.filter(p => p.post_id === id)[0]
    }
  },
  watch: {}
}