import globalTypes from '@/store/mutation-types'
import icons from '@/mixins/icons.js'
import basicOperations from '@/mixins/basic-operations'
import * as mutationTypes from '@/store/mutation-types.js'
import UIText from '@/mixins/ui-text.js'
import colors from '@/mixins/colors.js'
import Post from '@/components/complementarities/post/post.vue'
//  const basicOperations = require('@/mixins/basic-operations.js')
import DropdownInPlace from '@/components/utils/dropdown-in-place/dropdown-in-place.vue'
import Swatches from 'vue-swatches'
import "vue-swatches/dist/vue-swatches.min.css"
import VueUploadComponent from 'vue-upload-component'
import { TYPE } from "vue-toastification";

import Cropper from 'cropperjs'
import Vue from 'vue'
export default {
  name: 'Add',
  mixins: [basicOperations, icons, UIText, colors],
  components: {
    Post,
    Swatches,
    DropdownInPlace,
    FileUpload: VueUploadComponent
  },
  data() {
    return {
      imgID: 'postimg-' + this.$store.state.profile.p_id + '-' + new Date().getTime(),
      videoID: 'postvideo-' + this.$store.state.profile.p_id + '-' + new Date().getTime(),
      description: '',
      questionnaire: false,
      toBeUploadedPhoto: [],
      toBeUploadedVideo: [],
      selectedTags: [],
      options: [],
      showOptions: true
    }
  },

  mounted() {
  },

  computed: {
    profile() {
      return this.$store.state.profile
    },
    lang() {
      return this.$store.state.lang
    },
    getPlaceholder() {
      if (this.questionnaire) {
        if (this.lang === 'tr') {
          return 'Bir soru sor'
        }
        if (this.lang === 'nl') {
          return 'Stel een vraag'
        }
        if (this.lang === 'fr') {
          return 'Poser une question'
        }
      } else {
        if (this.lang === 'tr') {
          return 'Tüm Belçika ile ne paylaşmak istersiniz?'
        }
        if (this.lang === 'nl') {
          return 'Wat wil je delen met de hele België?'
        }
        if (this.lang === 'fr') {
          return 'Que voulez-vous partager avec toute la Belgique?'
        }
      }
    },
    toBeUploadedPhotoUrl() {
      return `http://173.212.229.149:8448/uploader/img`
    },
    toBeUploadedVideoUrl() {
      return `http://173.212.229.149:8448/uploader/video`
    },
    toBeShownTags() {
      if (this.selectedTags.length > 0) {
        return this.$store.state.allTags.filter(t => this.selectedTags.filter(st => st === t.tag_id).length > 0)
      }
      return []
    },
    postErrors() {
      if (this.description.length === 0 && this.toBeUploadedPhoto.length === 0 && this.toBeUploadedVideo.length === 0) {
        if (this.lang === 'tr') {
          return 'Lütfen paylasiminizi tamamlayin'
        } else if (this.lang === 'nl') {
          return 'Gelieve je post te vervolledigen'
        } else if (this.lang === 'fr') {
          return 'Merci de compléter votre message'
        }
      }
      return ''
    }
  },
  created() {
    this.options = [{
      optionPlaceholder: this.UIText.add.option[this.lang] + ' 1',
      optionName: ''
    }, {
      optionPlaceholder: this.UIText.add.option[this.lang] + ' 2',
      optionName: ''
    }, {
      optionPlaceholder: this.UIText.add.option[this.lang] + ' 3',
      optionName: ''
    }]
    this.$store.commit('SET_SPECIAL_BUTTON', {
      label: this.UIText.add.send[this.lang],
      toBeExecutedFunction: () => {
        this.sendPost()
      }
    })
  },
  methods: {
    focussed(hm) {
      console.log('focussed')
      console.log(hm)
      this.showOptions = true
    },
    focusOut(hm) {
      console.log('focusOut')
      console.log(hm)
      this.showOptions = true
    },
    addOption() {
      let newOptions = this.options
      newOptions.push({
        optionPlaceholder: this.UIText.add.option[this.lang] + ' ' + (this.options.length + 1),
        optionName: ''
      })
      Vue.set(this, 'options', newOptions)
    },
    deleteOption(idx) {
      let newOptions = this.options
      newOptions.splice(idx, 1)
      Vue.set(this, 'options', newOptions)
    },
    inputPhoto(newFile, oldFile) {
      console.log('inputphoto')
      console.log(newFile)
      if (newFile && newFile.success) {
        this.allFinished()
      }
    },
    inputVideo(newFile, oldFile) {
      console.log('inputvideo')
      if (newFile && newFile.success) {
        this.allFinished()
      }
    },
    sendNotifications(postID) {
      let profile = this.$store.state.profile
      if (!profile.Followers || profile.Followers.length === 0) {
        return 0
      }
      let followers = profile.Followers.split(',')
      for (let i = 0; i < followers.length; i++) {
        this.$store.dispatch({
          type: 'createNotification',
          noti_type: 5,
          fk_for_profile: followers[i],
          fk_post: postID
        })
      }
    },
    sendPost() {
      let self = this
      if (this.postErrors.length > 0) {
        this.$toast(this.postErrors, {
          type: TYPE.ERROR
        });
        return false
      }
      let toBeSentPostObject = {
        post_type: 1,
        post_nofviews: 1,
        post_description: this.description,
        post_photo_link: '',
        fk_profile: this.$store.state.profile.p_id
      }
      if (this.toBeUploadedPhoto.length > 0) {
        toBeSentPostObject.post_type = 2
        toBeSentPostObject.post_photo_link = `https://img.burada.be/posts/img/${this.imgID}.${this._getExtension(this.toBeUploadedPhoto[0].name)}`
      } else if (this.toBeUploadedVideo.length > 0) {
        toBeSentPostObject.post_type = 3
        toBeSentPostObject.post_video_link = `https://img.burada.be/posts/video/${this.videoID}.${this._getExtension(this.toBeUploadedVideo[0].name)}`
      } else if (this.questionnaire) {
        toBeSentPostObject.post_type = 4
      }
      console.log(toBeSentPostObject)
      this.$store.dispatch({
        type: 'postPost',
        toBeSentObject: toBeSentPostObject,
        successCallback: (res) => {
          console.log(res)
          if (toBeSentPostObject.post_type == 2) {
            this.$store.commit('LOCK_SCREEN')
            self.uploadPhoto(res.data.Document)
          } else if (toBeSentPostObject.post_type == 3) {
            this.$store.commit('LOCK_SCREEN')
            self.uploadVideo(res.data.Document)
          } else if (toBeSentPostObject.post_type == 4) {
            this.$store.dispatch({
              type: 'postChoices',
              postID: res.data.Document,
              choices: this.options,
              successCallback: () => {
                self.allFinished(res.data.Document)
              }
            })
          } //post_Type == 1
          else {
            self.allFinished(res.data.Document)
          }
        }
      })
    },
    allFinished(postID) {
      if (postID) {
        this.sendNotifications(postID)
      }
      this.$toast(this.UIText.postIsSent[this.lang])
      this.$store.commit('UNLOCK_SCREEN')
      // this.$store.commit(mutationTypes.ADD_POST_TO_FRONT, this.postedPostObject)
      this.$store.dispatch({
        type: 'getNewPosts',
        successCB: () => {
          this.$router.push('/home')
          setTimeout(() => {
            this._goToHomeHead()
          }, 300)
        }
      })
      // this.$store.commit(mutationTypes.SHOW_MESSAGE, this.UIText.add.postIsSent[this.lang])
    },
    uploadPhoto(postID) {
      this.$refs.uploadphoto.active = true
      this.sendNotifications(postID)
    },
    uploadVideo(postID) {
      this.$refs.uploadVideo.active = true
      this.sendNotifications(postID)
    }
  },

  watch: {},
}