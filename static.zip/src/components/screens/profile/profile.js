import VModal from 'vue-js-modal'
import Vue from "vue";
Vue.use(VModal);
import icons from '@/mixins/icons.js'
import basicOperations from '@/mixins/basic-operations'
import * as mutationTypes from '@/store/mutation-types.js'
import Post from '@/components/complementarities/post/post.vue'
import UIText from '@/mixins/ui-text.js'

export default {
  name: 'Profile',
  mixins: [basicOperations, icons, UIText],
  components: {
    Post
  },
  data() {
    return {
      openProfileMenu: true,
      isMyProfile: false,
      publicProfile: true
    }
  },

  computed: {
    profilePosts() {
      if (this.profile && this.profile.PostIds && this.profile.PostIds !== null && this.profile.PostIds.length > 0) {
        let ppIds = this.profile.PostIds.split(',')
        // console.log(ppIds)
        return this.$store.state.allPosts.filter(function (p) {
          // console.log(p.post_id)
          return ppIds.filter(ppid => ppid == p.post_id).length > 0
        })
      } else {
        return []
      }
    },
    profile() {
      return this.$store.getters.getProfile(this.$route.params.profileID)
    },
    myPosts() {
      return this.$store.state.myPosts
    },
    totalViewsOfMessages() {
      if (this.isMyProfile) {
        return this.myPosts.map(p => p.ViewedProfiles).reduce((a, b) => a + b, 0)
      } else {
        return this.profilePosts.map(p => p.ViewedProfiles).reduce((a, b) => a + b, 0)
      }
    },
    profileContactPossibilities() {
      let p = []
      if (this.profile.p_gsm) {
        p.push('p_gsm')
      }
      if (this.profile.p_facebook) {
        p.push('p_facebook')
      }
      if (this.profile.p_instagram) {
        p.push('p_instagram')
      }
      if (this.profile.p_telephone) {
        p.push('p_telephone')
      }
      if (this.profile.p_website) {
        p.push('p_gsm')
      }
      return p
    },
    profileTags() {
      if (this.profile.ProfileTags !== null && this.profile.ProfileTags.length > 0) {
        return this.$store.getters.getTags(this.profile.ProfileTags.split(',').map(b => parseInt(b)))
      }
      return []
    },
  },
  created() { },
  mounted() {
    this.init()
    if (this.isMyProfile) {
      this.$store.commit('SET_SPECIAL_BUTTON', {
        label: this.UIText.sendToUs[this.lang],
        toBeExecutedFunction: () => {
          this.sendToUs()
        }
      })
    } else {
      this.$store.commit('SET_SPECIAL_BUTTON', {
        label: '',
        toBeExecutedFunction: () => {

        }
      })
    }
  },
  methods: {
    getProfile(id) {
      return this.$store.getters.getProfile(id)
    },
    addBlockedUser(pid){
      let blockedUsers = localStorage.blockedUsers
      if(blockedUsers && blockedUsers.length>0){
        localStorage.blockedUsers = blockedUsers + ',' + pid
      }else{
        localStorage.blockedUsers = pid
      }
    },
    detailsClicked() {
      this.$fire({
        showConfirmButton: true,
        showCancelButton: true,
        confirmButtonText: this.UIText.blockUser[this.lang],
        cancelButtonText: this.UIText.cancel[this.lang],
      }).then(r => {
        console.log(r)
        if (r.value) {
          console.log('block user')
          this.addBlockedUser(this.profile.p_id)
          this.$toast(this.UIText.userBlocked[this.lang])
          this.$router.go(-1)
        } else {
          console.log('iptal')
        }
      })
    },
    getGridClass() {
      let res = 0
      if (this.profile.lo_id !== '') {
        res++
      }
      if (this.profile.p_telephone !== '') {
        res++
      }
      if (this.profile.p_whatsapp !== '') {
        res++
      }
      if (this.profile.p_facebook !== '') {
        res++
      }
      if (this.profile.p_instagram !== '') {
        res++
      }
      if (this.profile.p_twitter !== '') {
        res++
      }
      if (this.profile.p_pinterest !== '') {
        res++
      }
      if (this.profile.p_website !== '') {
        res++
      }
      if (this.profile.p_twitter !== '') {
        res++
      }
      if (res >= 5) {
        return 'col-2'
      }
      if (res === 4) {
        return 'col-3'
      }
      if (res === 3) {
        return 'col-4'
      }
      if (res === 2) {
        return 'col-6'
      }
      if (res === 1) {
        return 'col-12'
      } else {
        return 'col-12'
      }
    },
    sendToUs() {
      this.$fire({
        title: this.UIText.sendToUs[this.lang],
        // text: 'selam',
        input: 'textarea',
        inputLabel: this.UIText.yourMessage[this.lang],
        confirmButtonText: this.UIText.justSend[this.lang],
        inputPlaceholder: this.UIText.yourMessage[this.lang]
      }).then(r => {
        console.log(r.value)
        if (r.value) {
          this.$store.dispatch({
            type: 'postQuestion',
            qu_type: 1,
            message: r.value,
            successCallback: () => {
              this.$toast(this.UIText.postIsSent[this.lang])
            }
          })
        }
      });
    },
    updateProfileClicked() {
      this.$router.push({
        name: 'updateprofile',
        params: {
          profileID: this.$store.state.user.fk_profile
        }
      })
    },
    goToSettings() {
      this.$router.push({
        name: 'settings'
      })
    },
    getChatOfProfile() {
      let chat = this.$store.state.allMessages[this.profile.p_id]
      if (chat) {
        return chat
      }
      return []
    },
    goToSendMessage() {
      this.$store.commit('SET_HEADER_TITLE', {
        tr: this.profile.p_username + ' ile sohbet',
        nl: 'Gesprek met ' + this.profile.p_username,
        fr: 'Conversation avec ' + this.profile.p_username,
      })
      console.log('hm')
      this.$router.push({
        name: 'chat',
        params: {
          chat: this.getChatOfProfile(),
          profile: this.profile
        }
      })
    },
    getNumberOfFollowers() {
      if (!this.profile.Followers || this.profile.Followers.length === 0) {
        return 0
      }
      return this.profile.Followers.split(',').length
    },
    getNumberOfFollowings() {
      if (!this.profile.Followings || this.profile.Followings.length === 0) {
        return 0
      }
      return this.profile.Followings.split(',').length
    },
    amIFollowing() {
      if (this.$store.state.profile.Followings && this.$store.state.profile.Followings.length > 0) {
        return this.$store.state.profile.Followings.split(',').filter(pid => pid == this.profile.p_id).length > 0
      }
      return false
    },
    follow(followWithNotification) {
      if (this.amIFollowing()) {
        this.$store.dispatch({
          type: 'unfollow',
          following: this.$route.params.profileID,
          successCB: (res) => {

          }
        })
      } else {
        this.$store.dispatch({
          type: 'follow',
          followed: this.$store.state.user.fk_profile,
          following: this.$route.params.profileID,
          followWithNotification: 1,
          successCB: (res) => {
            this.$store.dispatch({
              type: 'createNotification',
              noti_type: 3,
              fk_for_profile: this.profile.fk_profile
            })
          }
        })
      }
    },
    init() {
      if (this.$route.params.profileID == this.$store.state.user.fk_profile) {
        this.isMyProfile = true
      } else {
        this.isMyProfile = false
      }
      // this.$store.dispatch({
      //   type: 'getFollowers',
      //   profileID: this.$route.params.profileID
      // })
    }
  },
  watch: {
    '$route.params.profileID': function () {
      this.init()
    }
  }
}