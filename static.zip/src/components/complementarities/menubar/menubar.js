import Vue from 'vue'
import * as mutationTypes from '@/store/mutation-types.js'
import icons from '@/mixins/icons'
import basicOperations from '@/mixins/basic-operations'
export default {
  name: 'Menubar',
  mixins: [icons, basicOperations],
  components: {},
  data() {
    return {
      isMenuOpen: false,
      current: '/',
      backButtonAvailable: false,
      specialButtonAvailable: false,
      showHeaderTitle: false
    }
  },
  computed: {
    lang() {
      return this.$store.state.lang
    },
    specialButton() {
      return this.$store.state.specialButton
    },
    numberOfUnredMessages() {
      let res = 0
      let profiles = Object.values(this.$store.state.allMessages)
      for (let i = 0; i < profiles.length; i++) {
        if (profiles[i].filter(m => m.pm_viewed === 0).length > 0) {
          res++
        }
      }
      return res
    },
    numberOfUnviewedNotifications() {
      return this.$store.state.notifications.filter(m => m.noti_viewed === 0).length
    },
    loggedIn() {
      return this.$store.state.flags.loggedIn
    },
    isRightSideMenuOpen() {
      return this.$store.state.menubarItems.isRightSideMenuOpen
    },
    titelbalkLinks() {
      return this.$store.state.menubarItems.left
    },
    titelbalkTitel() {
      return this.$store.state.menubarItems.title
    },
    titelbalkRechts() {
      return this.$store.state.menubarItems.right
    },
    textButtons() {
      return this.$store.state.menubarItems.rightAsTextButtons
    },
    rightSideMenuItems() {
      return this.$store.state.menubarItems.rightSideMenuItems
    }
  },
  methods: {
    refresh(){
      this.$store.dispatch('getAllProfiles')
      this.$store.dispatch('getAllPosts')
      this.$store.dispatch('getAllCategories')
      this.$store.dispatch('getAllMessages')
      this.$store.dispatch('getAllNotifications')
      this.$store.dispatch('getAllTags')
      this.$store.dispatch('getAllProvincesAndTowns')
      this.$store.dispatch('getAdTab')
      this.$store.commit('ALL_CATCHED')
      setTimeout(() => {
        this._goToHomeHead()
      }, 300)
    },
    goToMessages() {
      this.$router.push({
        name: 'mymessages'
      })
    },
    goToNotifications() {
      this.$router.push({
        name: 'notifications'
      })
    },
    toggleMenu() {
      console.log(this.isMenuOpen)
      this.isMenuOpen = !this.isMenuOpen
      console.log(this.isMenuOpen)
    },
    toggleRightSideMenu(status, itemright) {
      if (typeof itemright === 'undefined' || typeof itemright.cascading === 'undefined' || !itemright.cascading) {
        this.$store.commit(mutationTypes.SET_MENUBAR_RIGHT_SIDE_MENU_VISIBLE, status)
      }
    },
    longpressTooltipMenubar(item) {
      return function (event) {
        if (event !== undefined) {
          event.preventDefault()
        }
        if (typeof item.FUNCTIE_HELP !== 'undefined') {
          item.FUNCTIE_HELP()
        }
      }.bind(this)
    },
    rightClickTooltipMenubar(item, event) {
      if (typeof item.FUNCTIE_HELP !== 'undefined') {
        event.preventDefault()
        item.FUNCTIE_HELP()
      }
    },
    getTextButtonClass(item) {
      return item.getTextButtonClass()
    },
    goBack() {
      this.$router.go(-1)
    },
    arrangeCurrentRoute(route) {
      this.current = route.name
    },
    getHeaderTitle() {
      if (this.showHeaderTitle) {
        return this.$store.state.headerTitle[this.lang]
      }
    }
  },

  watch: {

    $route(to, from) {
      // console.log('from: ')
      // console.log(from)
      this.isMenuOpen = false
      this.backButtonAvailable = to.meta.backButtonAvailable
      this.specialButtonAvailable = to.meta.specialButtonAvailable
      this.showHeaderTitle = to.meta.showHeaderTitle
      // console.log('route changed')
      // console.log(to)
      this.arrangeCurrentRoute(to)
    }
  }
}