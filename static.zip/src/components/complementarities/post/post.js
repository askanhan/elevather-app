import * as globalTypes from '@/store/mutation-types'
import icons from '@/mixins/icons.js'
import basicOperations from '@/mixins/basic-operations'
import * as mutationTypes from '@/store/mutation-types.js'

import UIText from '@/mixins/ui-text.js'
import AnimatedNumber from '@/components/utils/animated-number/animated-number.vue'
import VideoPlayer from '@/components/complementarities/video-player/video-player.vue'
//  const basicOperations = require('@/mixins/basic-operations.js')

import Vue from 'vue'
import moment from 'moment'
export default {
  name: 'Post',
  props: {
    post: Object,
    // examplePost: Object,
    showType: {
      type: String,
      default: 'full'
    }
  },
  // props: ['id', 'examplePost'],
  mixins: [basicOperations, icons, UIText],

  components: {
    AnimatedNumber,
    VideoPlayer
  },
  data() {
    return {
      isVisible: false,
      // post: {},
      showComment: false,
      comments: [],
      currentView: 'full',
      examplePostActive: false,
      original_post_nofviews: 0,
      number_of_likes: 0,
      number_of_comments: 0,
      canBeThumbnailed: false,
      newComment: '',
      answeredByLoggedInUser: false,
      choices: [],
      answers: [],
      choiceScores: [],
      myAnswerIdx: 10,
      urlInDesc: 'no',
      likedByLoggedInUser: false
    }
  },

  computed: {
    profile() {
      return this.$store.getters.getProfile(this.post.fk_profile)
    },
    myProfile() {
      return this.$store.state.profile
    },
    tags() {
      if (this.profile.ProfileTags && this.profile.ProfileTags !== null && this.profile.ProfileTags.length > 0) {
        return this.$store.getters.getTags(this.profile.ProfileTags.split(',').map(b => parseInt(b)))
      }
      return this.$store.getters.getTags([95])
    },
    lang() {
      return this.$store.state.lang
    },
    viewedByLoggedInUser() {
      // if(this.post.ViewedProfiles !== null && this.post.ViewedProfiles){
      //   return this.post.ViewedProfiles !== null && this.post.ViewedProfiles.split(',').map(lp => parseInt(lp)).filter(p => p == this.$store.state.profile.p_id).length > 0
      // }
      return false
    },
    isMyPost() {
      return this.post.fk_profile == this.myProfile.fk_profile
    }
  },
  created() {
    this.currentView = this.showType
    if (this.showType === 'thumbnail') {
      this.canBeThumbnailed = true
    }
    // if (this.id == 0) { //examplePost
    //   this.post = this.examplePost
    //   this.examplePostActive = true
    //   // this.profile = this.examplePost.profile
    // } else {
    //   this.post = this.$store.state.allPosts.filter(p => p.post_id == this.id)[0]
    //   this.original_post_nofviews = this.post.post_nofviews
    //   this.post.post_nofviews = 0
    //   if (this.post) {
    //     this.profile = this.$store.state.allProfiles.filter(pp => pp.p_id == this.post.post_profile_fk)[0]
    //   }
    // }
  },
  mounted() {
    setTimeout(()=> {
      this.calculateLikedByLoggedInUser()
    }, 700)
  },
  destroyed() {
    console.log('post destroyed')
    sessionStorage.homeViewingPost = '#post-' + this.post.post_id
  },
  methods: {
    calculateLikedByLoggedInUser(){
      this.likedByLoggedInUser = this.post.LikedProfiles.filter(p => p == this.$store.state.profile.p_id).length > 0
    },
    detailsClicked() {
      this.$fire({
        showConfirmButton: true,
        showCancelButton: true,
        confirmButtonText: this.UIText.flagPost[this.lang],
        cancelButtonText: this.UIText.cancel[this.lang],
      }).then(r => {
        console.log(r)
        if (r.value) {
          console.log('flag post')
          this.$store.dispatch({
            type: 'postQuestion',
            qu_type: 2,
            message: 'Post sikayet edildi: ' + this.post.post_id + ' by ' + this.$store.state.profile.p_id,
            successCallback: () => {
              this.$toast(this.UIText.postIsSent[this.lang])
            }
          })
        } else {
          console.log('block user')
        }
      })
    },
    deleteYourPostClicked() {
      this.$fire({
        title: this.UIText.dikkat[this.lang],
        text: this.UIText.delPost[this.lang],
        showConfirmButton: true,
        showCancelButton: true,
        confirmButtonText: this.UIText.yes[this.lang],
        cancelButtonText: this.UIText.cancel[this.lang],
      }).then(r => {
        if (r.value) {
          console.log('yes')
          this.$store.dispatch({
            type: 'deletePost',
            postID: this.post.post_id,
            successCB: (res) => {
              console.log('deleted')
            }
          })
        } else {
          console.log('no')
        }
      })
    },
    share() {
      if (this._isAndroid) {
        window.plugins.socialsharing.share(this.post.post_description, null, this.post.post_type == 1 ? null : this.post.post_type == 2 ? this.post.post_photo_link : this.post.post_video_link, 'www.burada.be')
      } else { //ios
        let options = {
          message: this.post.post_description, // not supported on some apps (Facebook, Instagram)
          url: this.post.post_type == 2 ? this.post.post_photo_link : this.post.post_type == 3 ? this.post.post_video_link : 'https://burada.be'
        }
        window.plugins.socialsharing.shareWithOptions(options)
      }
    },
    loadNecessaritiesIfQuestionnaire() {
      if (this.post.post_type == 4) {
        if (this.choices.length === 0) {
          this.$store.dispatch({
            type: 'getChoices',
            postID: this.post.post_id,
            successCB: (res) => {
              console.log(res)
              this.choices = res
              this.fetchAnswers()
            }
          })
        } else {
          this.fetchAnswers()
        }
      }
    },
    fetchAnswers() {
      this.$store.dispatch({
        type: 'getAnswers',
        postID: this.post.post_id,
        successCB: (res) => {
          console.log(res)
          if (res.length > 0) {
            this.answers = res
          }
          this.answeredByLoggedInUser = this.answers.length > 0 && this.answers.filter(a => a.fk_profile === this.$store.state.profile.p_id).length > 0
          if (this.answeredByLoggedInUser) {
            this.loadAnswers()
          }
        }
      })
    },
    getProfile(id) {
      return this.$store.getters.getProfile(id)
    },
    toggleComment() {
      this.showComment = !this.showComment
      if (this.showComment) {
        // let self = this
        // setTimeout(function () {
        //   self.$refs.postsRef.focus()
        // }, 300)
      }
    },
    makeChoice(pchoID, idx) {
      if (!this.answeredByLoggedInUser) {
        this.$store.dispatch({
          type: 'postAnswer',
          postID: this.post.post_id,
          choiceID: pchoID,
          successCB: () => {
            this.myAnswerIdx = idx
            let answ = this.answers
            answ.push({
              fk_post_choice: pchoID,
              fk_profile: this.$store.state.profile.p_id
            })
            Vue.set(this, 'answers', answ)
            this.answeredByLoggedInUser = true
            this.loadAnswers()
          }
        })
      }
    },
    loadAnswers() {
      let choiceScores = Array(this.choices.length).fill(0)
      if (this.answers.length > 0) {
        for (let i = 0; i < this.answers.length; i++) {
          for (let j = 0; j < this.choices.length; j++) {
            if (this.answers[i].fk_post_choice === this.choices[j].pcho_id) {
              choiceScores[j]++
            }
            if (this.answers[i].fk_profile === this.$store.state.profile.p_id) {
              this.myAnswerIdx = j
            }
          }
        }
      }
      this.choiceScores = choiceScores.map(c => parseInt((c / this.answers.length) * 100))
      for (let i = 0; i < this.choices.length; i++) {
        this.extendCBarToSpecifiedWidth(this.choices[i].pcho_id, this.choiceScores[i])
      }
    },
    extendCBarToSpecifiedWidth(choiceID, until) {
      console.log('until::::::::::::::::::::::::::::::::::::::' + until)
      let self = this
      let width = 1;
      let id = setInterval(frame, 20);
      self.$refs[self.post.post_id + 'cbar' + choiceID][0].style.width = '1%'
      function frame() {
        if (width >= until) {
          clearInterval(id)
        } else {
          try {
            self.$refs[self.post.post_id + 'cbar' + choiceID][0].style.width = (parseInt(self.$refs[self.post.post_id + 'cbar' + choiceID][0].style.width.split('%')[0]) + 1) + '%'
            width++
          } catch (e) {
            clearInterval(id)
          }
        }
      }
    },
    postComment() {
      if (this.newComment && this.newComment.length > 0) {
        this.$store.dispatch({
          type: 'postComment',
          postID: this.post.post_id,
          comment: this.newComment,
          successCB: () => {
            let copiedT = _.cloneDeep(this.newComment)
            this.post.comments.push({
              comment: copiedT,
              fk_profile: this.$store.state.profile.p_id
            })
            this.newComment = ''
            this.number_of_comments++
            this.showComment = true
            this.$store.dispatch({
              type: 'createNotification',
              noti_type: 2,
              fk_for_profile: this.post.fk_profile,
              fk_post: this.post.post_id
            })
          }
        })
      }
    },
    linkify(text) {
        var urlRegex = /(((https?:\/\/)|(www\.))[^\s]+)/g;
        let self = this
        return text.replace(urlRegex, function(url) {
          url = url.startsWith('www') ? 'https://' + url : url
          self.urlInDesc = url
          return '<a class="builtinlink">' + url + '</a>';
        })
        // or alternatively
        // return text.replace(urlRegex, '<a href="$1">$1</a>')
    },
    openLinkIfAny(){
      if(this.urlInDesc !== 'no'){
        this._openWebsite(this.urlInDesc)
      } 
    },
    animateNumbers() {
      // this.$store.dispatch({
      //   type: 'getChoices',
      //   postID: this.post.post_id,
      //   successCB: (res) => {
      //     console.log(res)
      //     this.choices = res
      //     this.fetchAnswers()
      //   }
      // })
      // if (this.post.ViewedProfiles !== null) {
      //   this.post.post_nofviews = this.post.ViewedProfiles.split(',').length
      // }
      this.number_of_likes = this.post.LikedProfiles.length
      this.number_of_comments = this.post.comments.length
      if(this.number_of_comments > 0){
        this.showComment = true
      }
      // if (this.post.CommentedProfiles !== null) {
      //   this.comments = this.post.CommentedProfiles.split('$-=ùµ^$')
      //   this.comments = this.comments.map(function (comment) {
      //     return {
      //       fk_profile: comment.split('µ£*+%')[0],
      //       comment: comment.split('µ£*+%')[1],
      //     }
      //   })
      //   this.number_of_comments = this.comments.length
      // }
    },
    goToTagPosts(tag) {
      console.log('fffff')
      this.$emit('tag-clicked', tag)
    },
    goToProfile(ppID) {
      sessionStorage.homeViewingPost = '#post-' + this.post.post_id
      this.$router.push({
        name: 'profile',
        params: {
          profileID: ppID
        }
      })
    },
    thumbnailClicked() {
      console.log('thumbnailClicked')
      console.log(this.currentView)
      if (this.currentView === 'thumbnail') {
        this.currentView = 'full'
      } else if (this.canBeThumbnailed) {
        this.currentView = 'thumbnail'
      }
    },
    doNothing() {

    },
    getFromNow() {
      return new moment(this.post.post_date).fromNow()
    },
    makeSmall() {
      this.currentView = 'thumbnail'
    },
    visibilityChanged(isVisible, entry) {
      this.isVisible = isVisible
      console.log('visibilityChanged: ' + isVisible)
      if (this.isVisible) {
        this.animateNumbers()
        this.loadNecessaritiesIfQuestionnaire()
      }
      if (!this.viewedByLoggedInUser) {
        this.$store.dispatch({
          type: 'postViewed',
          postID: this.post.post_id
        })
      }
      // console.log(entry)
    },
    increaseLike() {
      if (this.likedByLoggedInUser) {
        this.$store.dispatch({
          type: 'postUnlike',
          postID: this.post.post_id,
          successCB: () => {
            this.number_of_likes--
            this.calculateLikedByLoggedInUser()
          }
        })
      } else {
        this.$store.dispatch({
          type: 'postLike',
          postID: this.post.post_id,
          successCB: () => {
            this.number_of_likes++
            this.calculateLikedByLoggedInUser()
            this.$store.dispatch({
              type: 'createNotification',
              noti_type: 1,
              fk_for_profile: this.post.fk_profile,
              fk_post: this.post.post_id
            })
          }
        })
      }

    },
  },
  watch: {}
}