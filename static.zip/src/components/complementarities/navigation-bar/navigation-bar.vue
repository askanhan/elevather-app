<template src="./navigation-bar.html"></template>
<script src="./navigation-bar.js"></script>
<style src="./navigation-bar.css" scoped></style>
