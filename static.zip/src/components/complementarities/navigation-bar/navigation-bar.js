import Vue from 'vue'
import UIText from '@/mixins/ui-text.js'
import * as mutationTypes from '@/store/mutation-types.js'
import basicOperations from '@/mixins/basic-operations'
import icons from '@/mixins/icons'
export default {
  name: 'NavigationBar',
  mixins: [icons, UIText, basicOperations],
  data() {
    return {
      current: '/'
    }
  },
  computed: {
    lang() {
      return this.$store.state.lang
    },
    loggedIn() {
      return this.$store.state.flags.loggedIn
    }
  },
  methods: {
    homeSelected() {
      if (this.current === 'home') {
        this.$store.dispatch({
          type: 'getNewPosts',
          successCB: () => {
            setTimeout(() => {
              this._goToHomeHead()
            }, 300)
          },
          errorCB: () => {
            setTimeout(() => {
              this._goToHomeHead()
            }, 300)
          }
        })
      } else {
        this.$router.push('/home')
      }
    },
    searchSelected() {
      this.$router.push('/search')
    },
    addSelected() {
      this.$router.push('/add')
    },
    adTabSelected() {
      this.$router.push('/ad-tab')
    },
    profileSelected() {
      this.$router.push({
        name: 'profile',
        params: {
          profileID: this.$store.state.user.fk_profile
        }
      })
    },
    arrangeCurrentRoute(route) {
      this.current = route.name
    },
  },

  watch: {

    $route(to, from) {
      this.isMenuOpen = false
      this.arrangeCurrentRoute(to)
    }
  }
}