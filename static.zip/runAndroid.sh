cd /cygdrive/C/Projects/appschoolware/build/

echo '***** Naar smartphone *****'
cordova run android

