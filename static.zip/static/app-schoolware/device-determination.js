var classNames = []
window.device= {}
console.log(navigator.userAgent)
if (navigator.userAgent.match(/(iPad|iPhone|iPod)/i)) {
  classNames.push('device-ios')
  window.device.platform='ios'
}
if (navigator.userAgent.match(/android/i)) {
  classNames.push('device-android')
  window.device.platform='android'
}

var html = document.getElementsByTagName('html')[0]

if(/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
  classNames.push('on-device')
  window.device.platform='other'
  window.device.mobileOrTablet=true
  window.device.pc=false
} else {
  classNames.push('on-pc')
  window.device.mobileOrTablet=false
  window.device.pc=true
}

if (html.classList) {
  html.classList.add.apply(html.classList, classNames)
} else {
  html.classList = classNames
}
