/* global $ */

// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from "vue";
import App from "@/components/app/app.vue";
import store from "@/store";
import * as globalTypes from "@/store/mutation-types.js";
import router from "@/router";
import VueAutosuggest from "vue-autosuggest"
/* Directives */
import '@/directives/general-directives.js'

/* Filters */
import '@/filters/date-filters.js'
import '@/filters/string-filters.js'

/* Defining Vue specific modules */
import Vuex from "vuex";
import axios from "axios";
import VueAxios from "vue-axios";
import VueTouch from "vue-touch";
import VueSidebarMenu from 'vue-sidebar-menu'
import 'vue-sidebar-menu/dist/vue-sidebar-menu.css'

import globalCss from "./main.css";

import Vue2TouchEvents from "vue2-touch-events";
import {
  ObserveVisibility
} from 'vue-observe-visibility'

import "babel-polyfill";
import Es6Promise from "es6-promise";
Es6Promise.polyfill();
import VueSimpleAlert from "vue-simple-alert";

import moment from 'moment'
import 'moment/locale/nl-be'
import 'moment/locale/fr'
import 'moment/locale/tr'
import VueScrollTo from 'vue-scrollto'
import VueSweetalert2 from 'vue-sweetalert2';

// If you don't need the styles, do not connect
import 'sweetalert2/dist/sweetalert2.min.css';

Vue.use(VueSweetalert2);

Vue.use(VueScrollTo)

// You can also pass in the default options
Vue.use(VueScrollTo, {
  container: "body",
  duration: 500,
  easing: "ease",
  offset: 0,
  force: true,
  cancelable: true,
  onStart: false,
  onDone: false,
  onCancel: false,
  x: false,
  y: true
})
import VModal from 'vue-js-modal'
Vue.use(VModal)
Vue.prototype.moment = moment
Vue.directive('observe-visibility', ObserveVisibility)
Vue.use(VueSimpleAlert);
Vue.use(Vue2TouchEvents
  /* , {
    disableClick: false,
    touchClass: "",
    tapTolerance: 10,
    swipeTolerance: 30,
    longTapTimeInterval: 400
  } */
);
Vue.use(VueSidebarMenu)
Vue.use(globalCss);

/* Use Vue specific modules */
Vue.use(Vuex);
Vue.use(VueAxios, axios);
Vue.use(VueTouch);
Vue.use(VueAutosuggest)
import VueAwesomeSwiper from 'vue-awesome-swiper'
import 'swiper/dist/css/swiper.css'
Vue.use(VueAwesomeSwiper, /* { default global options } */)
import { POSITION } from 'vue-toastification'
import Toast from "vue-toastification";
// Import the CSS or use your own!
import "vue-toastification/dist/index.css";
const options = {
  position: POSITION.BOTTOM_CENTER
};


Vue.use(Toast, options);
Vue.config.productionTip = false;

export const mainBus = new Vue();

/* eslint-disable no-new */

function checkSessionStorage() {
  console.log("checkSessionStorage");
  let vueRouting = sessionStorage.getItem("VUE_ROUTING");
  if (vueRouting !== null) {
    let puntenboekjeId = sessionStorage.getItem("VUE_PUNTENBOEKJEID");
    let loggedInUserInformation = {
      SessionConfig: {},
      UserData: {}
    };
    loggedInUserInformation.SessionConfig = JSON.parse(sessionStorage.getItem("VUE_SESSIE"));
    loggedInUserInformation.UserData.userid = parseInt(sessionStorage.getItem("VUE_USERID"));
    loggedInUserInformation.UserData.LLinkIDUsername = parseInt(sessionStorage.getItem("VUE_LLINKID_USERNAME"));
    loggedInUserInformation.UserData.LLinkIDPWD = parseInt(sessionStorage.getItem("VUE_LLINKID_PASSWORD"));
    loggedInUserInformation.menu = JSON.parse(sessionStorage.getItem("VUE_MENU"));
    loggedInUserInformation.rights = JSON.parse(sessionStorage.getItem("VUE_RIGHTS"));
    store.commit(globalTypes.SET_LOGGED_IN_USER_INFORMATION, loggedInUserInformation);

    store.commit(globalTypes.SET_USERS_TYPE, sessionStorage.getItem('VUE_USERTYPE'));

    store.commit(globalTypes.SET_LOGGED_IN_CONNECTION_OBJECT, JSON.parse(sessionStorage.getItem("VUE_LOGIN")));
    router.push(vueRouting);
  }
}
checkSessionStorage();

router.beforeEach((to, from, next) => {
  // store.commit(globalTypes.TOGGLE_MENU, false)
  next();
});

window.wisaVueApp = new Vue({
  el: "#app",
  store,
  router,
  components: {
    App
  },
  methods: {
    klasSelectie: function (value) {
      mainBus.$emit('extjs-klas-selectie', value);
    },
    scrollToFirstItemOfMonth: function (params) {
      mainBus.$emit('extjs-scroll-to-first-item-of-month', params);
    },
    activateSavedActivity: function (params) {
      mainBus.$emit('extjs-activate-saved-activity', params);
    },
    activateSelectedActivity: function (value) {
      mainBus.$emit('extjs-activate-selected-activity', value);
    }
  },
  template: "<App/>"
  // render: h => h(App) // ofwel components: { App } /////////////////////////
});

window.mainVueApp = {
  initialize: function () {
    this.bindEvents();
    this.setupVue();
  },
  bindEvents: function () {
    document.addEventListener("deviceready", this.onDeviceReady, false);
    // if (window.location.host.indexOf("localhost") !== -1) {
    // }
  },
  onDeviceReady: function () {
    window.open = cordova.InAppBrowser.open
    // voor APP
    window.mainVueApp.receivedEvent("deviceready");

    // if (cordova.platformId === "android") {
    StatusBar.backgroundColorByHexString("#f9f9f9");
    // }

    // Keyboard openen => focus in dit element leggen zodat dit terug in het nog resterende zichtbare deel van het scherm komt te staan
    $("body").on("focusin", "input, textarea", function (event) {
      window.latestElement = $(event.target);
    });
    $(window).resize(function () {
      setTimeout(function () {
        if (window.latestElement !== undefined) {
          window.latestElement[0].scrollIntoView();
        }
      }, 100);
    });

    cordova.getAppVersion.getVersionNumber(function (version) {
      console.log("versienummer: " + version);
    });

    cordova.getAppVersion.getAppName(function (appname) {
      console.log("projectNaam: " + appname);
      /* 
            store.commit(globalTypes.SSS, appname);
            */
    });

    // https://cordova.apache.org/docs/en/latest/reference/cordova-plugin-file/
    // Deze pc\ALE-L21\Interne opslag\Android\data\com.wisa.afwezighedenSecundairDebug\files

    // Enable to debug issues.
    // window.plugins.OneSignal.setLogLevel({logLevel: 4, visualLevel: 4});

    var notificationOpenedCallback = function (jsonData) {
      console.log(jsonData);
      if (jsonData && jsonData.notification && jsonData.notification.payload && jsonData.notification.payload.launchURL) {
        window.pushBerichtAvailable = true
        window.pushBericht = jsonData
        window.pushBerichtArgs = {}
        window.pushBerichtArgs.url = jsonData.notification.payload.launchURL.split('xxx://')[1].split('/')[0]
        window.pushBerichtArgs.params = jsonData.notification.payload.launchURL.split('xxx://')[1].split('/')[1]
        if (window.pushBerichtArgs.params) {
          let argArrays = window.pushBerichtArgs.params.split('&')
          window.pushBerichtArgs.params = {}
          for (let i = 0; i < argArrays.length; i++) {
            let varValPair = argArrays[i].split('=')
            window.pushBerichtArgs.params[varValPair[0]] = varValPair[1]
          }
        }
      } else {
        window.pushBerichtAvailable = false
      }
    };

    window.plugins.OneSignal
      .startInit("0b828c94-7784-4da6-ab95-52e82f4dddb2")
      .handleNotificationOpened(notificationOpenedCallback)
      .endInit();

  },
  receivedEvent: function (id) {
    console.log("Received Event: " + id);
  },
  setupVue: function () {
    window.wisaVueApp
  }
};

window.currentVueApp = window.mainVueApp.initialize();

window.parent.getVueWindowScope = function () {
  return window
}