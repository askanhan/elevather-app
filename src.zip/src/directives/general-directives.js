import Vue from 'vue'
import strOperations from '@/mixins/string-operations.js'
Vue.directive('begin-met-hoofdletter', {
  bind: function (el, binding) {
    let text = el.textContent
    el.textContent = strOperations.methods._capitalizeFirstLetters(text)
  }
})

const showInDesktopModeDirectiveFunction = function (el, binding) {
  let isDesktopModeOn = window.innerWidth > 800
  let showInDesktopMode = binding.expression === 'true'
  let showValue = binding.arg ? binding.arg : 'initial'
  if (isDesktopModeOn) {
    el.style.display = showInDesktopMode ? showValue : 'none'
  } else {
    el.style.display = showInDesktopMode ? 'none' : showValue
  }
  // console.log("----------------------------------------- SHOW IN DESKTOP MODE")
  // console.log(el, binding, window, isDesktopModeOn, showInDesktopMode, showValue)
  // console.log(window)
}

Vue.directive('show-in-desktop-mode', {
  bind: showInDesktopModeDirectiveFunction,
  componentUpdated: showInDesktopModeDirectiveFunction
})

Vue.directive('focus', {
  // When the bound element is inserted into the DOM...
  inserted: function (el) {
    // Focus the element
    el.focus()
  }
})

Vue.directive('long-press', {
  bind: function (el, binding, vNode) {
    // Make sure expression provided is a function
    if (typeof binding.value !== 'function') {
      // Fetch name of component
      const compName = vNode.context.name
      // pass warning to console
      let warn = `[longpress:] provided expression '${binding.expression}' is not a function, but has to be`
      if (compName) {
        warn += `Found in component '${compName}' `
      }

      console.warn(warn)
    }

    // var startElementID
    // var stopElementID
    var startX
    var startY

    let teller = 0
    let myTimer = (e) => {
      teller += 100
      // console.log('teller =' + teller)
    }

    var actieveTimer

    let touchStart = (e) => {
      teller = 0
      clearInterval(actieveTimer)
      console.log('touchStart op ' + e.currentTarget.id)
      startX = e.touches[0].pageX
      startY = e.touches[0].pageY
      console.log('e.touches[0].pageX = ' + startX)
      console.log('e.touches[0].pageY = ' + startY)
      /* var startElement = document.elementFromPoint(e.touches[0].pageX, e.touches[0].pageY)
      if (startElement.id === '') {
        startElementID = startElement.parentElement.id
      } else {
        startElementID = startElement.id
      }
      console.log('startElementID = ' + startElementID) */

      actieveTimer = setInterval(myTimer, 100)
    }

    let touchEnd = (e) => {
      console.log('touchEnd op  ' + e.currentTarget.id)
      // console.log('teller = ' + teller)
      if (teller > 500) {
        var endX = e.changedTouches[0].pageX
        var endY = e.changedTouches[0].pageY
        console.log('dit.changedTouches[0].pageX = ' + endX)
        console.log('dit.changedTouches[0].pageY = ' + endY)
        var afstandX = Math.abs(startX - endX)
        var afstandY = Math.abs(startY - endY)
        console.log('afstandX = ' + afstandX + ', afstandY = ' + afstandY)
        if (afstandX < 70 && afstandY < 60) {
          handler()
        }
        /* var stopElement = document.elementFromPoint(e.changedTouches[0].pageX, e.changedTouches[0].pageY)
        if (stopElement.id === '') {
          stopElementID = stopElement.parentElement.id
        } else {
          stopElementID = stopElement.id
        }
        console.log('stopElementID = ' + stopElementID)
        if (startElementID === stopElementID) {
          handler()
        } */
      }
      teller = 0
      clearInterval(actieveTimer)
    }

    let touchCancel = (e) => {
      teller = 0
      clearInterval(actieveTimer)
    }

    // Run Function
    const handler = (e) => {
      binding.value(e)
    }

    // Add Event listeners
    // el.addEventListener('mousedown', start)
    el.addEventListener('touchstart', touchStart, {
      passive: true
    })
    // Cancel timeouts if this events happen
    // el.addEventListener('click', cancel)
    // el.addEventListener('mouseout', cancel)
    el.addEventListener('touchend', touchEnd, {
      passive: true
    })
    el.addEventListener('touchcancel', touchCancel, {
      passive: true
    })
  }
})
