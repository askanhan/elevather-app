
import * as types from './mutation-types.js'
import HF from './help-functions.js'
import Vue from 'vue'
import iconsMixin from '@/mixins/icons.js'

const icons = iconsMixin.data().icons
const helpFunctions = new HF()

/* global $  */
export const mutations = {

  [types.LOCK_SCREEN](state, params) {
    let timing = 5000
    var doNotAutoEnable = null
    var customTimingScreenDisabled = null
    if (!_.isEmpty(params)) {
      doNotAutoEnable = params.doNotAutoEnable
      customTimingScreenDisabled = params.customTimingScreenDisabled
    }
    if (doNotAutoEnable) {
      state.flags.screenDisabled = true
      state.flags.screenLocked = true
    } else if (customTimingScreenDisabled > 0) {
      timing = customTimingScreenDisabled
      state.flags.screenDisabled = true
    } else {
      state.flags.screenLocked = true
    }
    if (!doNotAutoEnable) {
      setTimeout(function () {
        if (state.flags.screenLocked) {
          state.flags.screenLocked = false
        }
        if (state.flags.screenDisabled) {
          state.flags.screenDisabled = false
        }
      }, timing)
    }
  },
  [types.SET_LOGGED_IN_USER_INFORMATION](state, connection) {
    state.userInfo.loggedInUserInformation = connection
  },
  [types.SET_LOGGED_IN_CONNECTION_OBJECT](state, connectionObject) {
    state.userInfo.loggedInConnectionObject = connectionObject
  },
  [types.LOGGED_OUT_ONCE](state) {
    state.userInfo.loggedOutOnce = true
  },
  [types.UNLOCK_SCREEN](state) {
    state.flags.screenLocked = false
    state.flags.screenDisabled = false
  },

  [types.SHOW_MESSAGE](state, params) {
    $('#TOAST-MESSAGE-BOX').stop()
    $('#TOAST-MESSAGE-BOX').css('display', 'none')
    if (typeof params === 'string') {
      state.showedMessage = params
      $('#TOAST-MESSAGE-BOX').text(params)
      $('#TOAST-MESSAGE-BOX')
        .fadeIn(400)
        .delay(1000)
        .fadeOut(400)
    } else {
      state.showedMessage = params[0]
      $('#TOAST-MESSAGE-BOX').text(params[0])
      if (params[1] === 'error') {
        if (params[2] > 0) {
          $('#TOAST-MESSAGE-BOX')
            .fadeIn(400)
            .delay(params[2])
            .fadeOut(400)
        } else {
          $('#TOAST-MESSAGE-BOX')
            .fadeIn(400)
            .delay(2000)
            .fadeOut(400)
        }
      } else if (params[1] === 'long') {
        $('#TOAST-MESSAGE-BOX')
          .fadeIn(400)
          .delay(4000)
          .fadeOut(400)
      } else {
        $('#TOAST-MESSAGE-BOX')
          .fadeIn(400)
          .delay(1000)
          .fadeOut(400)
      }
    }
  },
  [types.LOGGED_IN](state) {
    state.flags.loggedIn = true
  },
  [types.LOGGED_OUT](state) {
    state.flags.loggedIn = false
  },
  [types.CHANGE_LANGUAGE](state, language) {
    state.lang = language
  },
  [types.SET_MY_PROFILE](state, profileObj) {
    state.myProfile = profileObj
  },
  [types.ALL_CATCHED](state) {
    state.allCatched = true
  },
  [types.SET_SPECIAL_BUTTON](state, specialButton) {
    state.specialButton = specialButton
  },
  [types.SET_HEADER_TITLE](state, title) {
    state.headerTitle = title
    console.log(state.headerTitle)
  },

  [types.SET_STATE_TO_INITIAL_VALUES](state) {
    let init = JSON.parse(JSON.stringify(state.initialValues))
    for (var property in init) {
      if (
        init.hasOwnProperty(property) &&
        property !== 'listOfConnections' &&
        property !== 'title' &&
        property !== 'versienummer'
      ) {
        state[property] = init[property]
      }
    }
  },
  [types.INITIALIZE_DROPDOWN_PAGE](state, payload) {
    // if dropdown was not defined before OR if it was given that data should be kept after made a selection
    if (
      typeof state.allDropdownMenus[payload.dropdownID] === 'undefined' ||
      !state.allDropdownMenus[payload.dropdownID].keepDataAfterSelection
    ) {
      let newDropdown = {}
      newDropdown.propertyToBeShown = payload.propertyToBeShown
      newDropdown.listOfItems = payload.listOfItems
      newDropdown.title =
        typeof payload.title !== 'undefined' ? payload.title : 'Maak een keuze'
      newDropdown.keepDataAfterSelection = typeof payload.keepDataAfterSelection !== 'undefined' ?
        payload.keepDataAfterSelection :
        true
      newDropdown.isMultiSelect = typeof payload.isMultiSelect !== 'undefined' ?
        payload.isMultiSelect :
        false
      newDropdown.showFilterBar = typeof payload.showFilterBar !== 'undefined' ?
        payload.showFilterBar :
        false
      newDropdown.atLeastOneSelectedItemRequired = typeof payload.atLeastOneSelectedItemRequired !== 'undefined' ?
        payload.atLeastOneSelectedItemRequired :
        false
      newDropdown.selectAllButtonName = payload.selectAllButtonName === 'undefined' ?
        'Selecteer alles' :
        payload.selectAllButtonName
      newDropdown.selectAllButtonVisible = typeof payload.selectAllButtonVisible !== 'undefined' ?
        payload.selectAllButtonVisible :
        false
      newDropdown.listOfItems.map(function (item, idx) {
        item._ID_DROPDOWN_PAGE = idx
        item._SELECTED_DROPDOWN_PAGE = typeof item._SELECTED_DROPDOWN_PAGE === 'undefined' ?
          false :
          item._SELECTED_DROPDOWN_PAGE
      })
      if (newDropdown.selectAllButtonVisible) {
        newDropdown.listOfItems.unshift({
          _ID_DROPDOWN_PAGE: -1,
          _SELECTED_DROPDOWN_PAGE: false,
          [newDropdown.propertyToBeShown]: newDropdown.selectAllButtonName
        })
      }
      state.allDropdownMenus[payload.dropdownID] = newDropdown
    }
    state.currentDropdownMenu = payload.dropdownID
  },
  [types.UPDATE_LIST_OF_ITEMS_OF_DROPDOWN](state, newListOfItems) {
    state.allDropdownMenus[state.currentDropdownMenu].listOfItems = {}
    state.allDropdownMenus[state.currentDropdownMenu].listOfItems = newListOfItems
  },
  [types.UNLOCK_LOGIN_PROCEDURE](state) {
    state.flags.loginProcedureLocked = false
  },
  [types.LOCK_LOGIN_PROCEDURE](state) {
    state.flags.loginProcedureLocked = true
  },
  [types.CLOSE_DIALOG](state, flag) {
    state.closeDialog = flag
  },
  [types.LAST_ACTIVE_DIALOG](state, dialog) {
    state.lastActiveDialog = dialog
  },
  [types.SET_CONNECTED_PROVINCE](state, pr) {
    state.connectedProvince = pr
  },
  [types.SET_LANG](state, lang) {
    state.lang = lang
  },
  [types.UPDATE_PROFILE](state, profileObj) {
    state.profile = _.merge(state.profile, profileObj)
  },
  [types.ADD_POST_TO_FRONT](state, post) {
    let newPostArray = state.allPosts
    newPostArray.unshift(post)
    state.allPosts = newPostArray
  },
}