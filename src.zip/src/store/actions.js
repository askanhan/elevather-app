import { TYPE } from "vue-toastification";
import * as types from './mutation-types.js'
import HF from './help-functions.js'
import * as mutationTypes from '@/store/mutation-types.js'
import router from '@/router/index.js'
import ST from '@/constants/server-types.js'
import axios from 'axios'

import * as globalMutationTypes from '@/store/mutation-types.js'

import bao from '@/mixins/basic-operations.js'
const basicOperations = bao.methods

import uit from '@/mixins/ui-text.js'
import moment from "moment";
const uiText = uit.data

const RS = require('@/services/rest.service.js')
const restService = new RS.default()
const helpFunctions = new HF()
const serverTypeConstants = new ST()
const instance = axios.create({
  headers: {
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
  }
})

function somethingWrongText(lang) {
  if (lang === 'tr') {
    return 'Bir hata oluştu, yeniden deneyin'
  } else if (lang === 'nl') {
    return 'Er is iets misgegaan, probeer opnieuw'
  }
}

function genericErrorFunction(res, commit, state) {
  if (res && res.response && res.response.data && res.response.data.message) {
    commit(types.SHOW_MESSAGE, res.response.data.message)
  } else {
    commit(types.SHOW_MESSAGE, somethingWrongText(state.lang))
  }
}

export const register = function ({
  dispatch,
  state,
  commit,
  rootState
}, payload) {
  restService.POST('profile', {
    p_username: payload.username
  }, (resProfile) => {
    console.log(resProfile.data.Document)
    let profileID = resProfile.data.Document
    restService.POST('user', {
      u_mail: payload.mail,
      u_password: payload.password,
      u_active: 1,
      fk_profile: profileID
    }, (resUser) => {
      console.log(resUser)
      if (resUser.data.Message && resUser.data.Message.errno) {
        this._vm.$toast('Lutfen baska bir mail adresi seçin', {
          type: TYPE.ERROR
        });
      } else {
        dispatch({
          type: 'login',
          email: payload.mail,
          password: payload.password,
          successCB: payload.successCB
        })
      }
    })
  })
}

export const login = function ({
  commit,
  state
}, payload) {
  restService.POST('token', { username: payload.email, password: payload.password }, (res) => {
    console.log(res)
    console.log(res.data.Document)
    let loggedin = {
      tr: 'Basariyla giris yaptiniz',
      nl: 'Succesvol aangemeld',
      fr: 'Inscription réussie'
    }
    this._vm.$toast(loggedin[state.lang], {
      type: TYPE.SUCCESS
    });
    state.flags.loggedIn = true
    state.profile = res.data.Document.profileResult
    state.user = res.data.Document.userResult
    state.token = res.data.Document.access_token
    localforage.setItem('token', res.data.Document.access_token)
    localforage.setItem('username', payload.email)
    localforage.setItem('password', payload.password)
    restService.POST('user_login', {
      ul_type: 'form',
      ul_ip: 'xxxxx',
      ul_device_details: "details",
      ul_app_version: "getVersion",
      fk_user: res.data.Document.userResult.u_id
    })
    localforage.setItem('LOGINRESULT', res.data.Document, () => {
      payload.successCB()
    })
  }, (err) => {
    try {
      this._vm.$toast(err.response.data.Document, {
        type: TYPE.ERROR
      });
    } catch (error) {
      this._vm.$toast('Bir hata olustu', {
        type: TYPE.ERROR
      });
    }
  })
}

export const addPost = function ({
  commit,
  state
}, payload) {


}

export const postQuestion = function ({
  commit,
  state
}, payload) {
  restService.POST(`question`, {
    fk_profile: state.profile.p_id,
    qu_type: payload.qu_type,
    qu_content: payload.message
  }, function (res) {
    payload.successCallback(res)
  })
}

export const postAnswer = function ({
  commit,
  state
}, payload) {
  restService.POST(`post_answer`, {
    fk_profile: state.profile.p_id,
    fk_post: payload.postID,
    fk_post_choice: payload.choiceID,
  }, function (res) {
    payload.successCB(res)
  })
}

export const postMessage = function ({
  commit,
  state
}, payload) {
  restService.POST(`private_message`, payload.toBeSentObject, function (res) {
    payload.successCB(res)
  })
}

export const postViewed = function ({
  commit,
  state
}, payload) {
  let self = this
  let successCallback = payload.successCallback
  restService.POST(`post_view`, {
    fk_post: payload.postID,
    fk_profile: state.profile.p_id
  }, () => { }, () => { }, false)
}

export const postPost = function ({
  commit,
  state
}, payload) {
  let self = this
  let successCallback = payload.successCallback
  restService.POST('post', payload.toBeSentObject, (res) => {
    console.log('hmm')
    payload.successCallback(res)
  }, function (res) {
    genericErrorFunction(res, commit, state)
  })
}

export const postComment = function ({
  commit,
  state
}, payload) {
  restService.POST(`post_comment`, {
    fk_post: payload.postID,
    fk_profile: state.profile.p_id,
    co_comment: payload.comment
  }, () => {
    state.allPosts = state.allPosts.map(function (p) {
      if (p.post_id == payload.postID) {
        let toBeAddedComment = state.profile.p_id + 'µ£*+%' + payload.comment
        if (p.CommentedProfiles === null) {
          p.CommentedProfiles = toBeAddedComment
        } else {
          p.CommentedProfiles = p.CommentedProfiles + '$-=ùµ^$' + toBeAddedComment
        }
      }
      return p
    })
    payload.successCB()
  })
}

export const createNotification = function ({
  commit,
  state
}, payload) {
  if (payload.fk_for_profile != state.profile.p_id) {
    let notObj = {
      noti_type: payload.noti_type,
      fk_for_profile: payload.fk_for_profile,
      fk_by_profile: state.profile.p_id
    }
    if (payload.fk_post) {
      notObj.fk_post = payload.fk_post
    }
    restService.POST(`notification`, notObj, () => { }, () => { }, false)
  }
}

export const postLike = function ({
  commit,
  state
}, payload) {
  restService.POST(`post_like`, {
    fk_post: payload.postID,
    fk_profile: state.profile.p_id,
    pl_like_type: 1
  }, () => {
    state.allPosts = state.allPosts.map(function (p) {
      if (p.post_id == payload.postID) {
        p.LikedProfiles.push(state.profile.p_id)
      }
      return p
    })
    payload.successCB()
  })
}

export const postUnlike = function ({
  commit,
  state
}, payload) {
  let postID = payload.postID
  restService.POST(`post_like/unlike`, {
    fk_post: payload.postID,
    fk_profile: state.profile.p_id
  }, () => {
    state.allPosts = state.allPosts.map(function (p) {
      if (p.post_id == payload.postID) {
        p.LikedProfiles = p.LikedProfiles.filter( pl => pl != state.profile.p_id)
      }
      return p
    })
    payload.successCB()
  })
}

// export const getCategories = function ({
//   commit,
//   state
// }, payload) {
//   restService.GET('category/get-followers/' + payload.profileID, {}, payload.successCallback)
// }

export const getRegionInfo = function ({
  dispatch,
  commit,
  state
}, payload) {
  let position = payload.position
  payload.successCB(undefined)
  // restService.GET(`https://geocode.xyz/${position.coords.latitude},${position.coords.longitude}?json=1`, {}, function (res) {
  //   console.log(res)
  //   payload.successCB(res.data)
  // }, (err) => {
  //   if (payload.tryNumber > 0) {
  //     setTimeout(() => {
  //       dispatch({
  //         type: 'getRegionInfo',
  //         position: payload.position,
  //         successCB: payload.successCB,
  //         tryNumber: payload.tryNumber - 1
  //       })
  //     }, 1500)
  //   }
  // }, false)
}

export const getAdTab = function ({
  commit,
  state
}, payload) {
  restService.GET('ad_tab', {}, function (res) {
    console.log(res)
    state.adTab = res.data.Document
  })
}

export const getFollowers = function ({
  commit,
  state
}, payload) {
  restService.GET('following/get-followers/' + payload.profileID, {}, payload.successCallback)
}

export const getAllProfiles = function ({
  commit,
  state
}, successCallback) {
  restService.GET('profile', {}, function (res) {
    console.log(res)
    state.allProfiles = res.data.Document.records
    state.profile = res.data.Document.records.filter(p => p.p_id === state.profile.p_id)[0]
    window.plugins.OneSignal.sendTags({
      userid: state.profile.u_id,
      tags: state.profile.ProfileTags,
      username: state.profile.p_username,
      gsm: state.profile.p_telephone,
      photo: state.profile.p_photo,
      mail: state.profile.u_mail,
      profileid: state.profile.p_id
    })
  })
}

export const getAllPosts = function ({
  dispatch,
  commit,
  state
}, successCallback) {
  restService.GET('post/all', {}, function (res) {
    console.log(res.data.Document.records)
    state.allPosts = res.data.Document
    state.receivedLastPostsOn = new moment()
    state.myPosts = state.allPosts.filter(p => p.fk_profile == state.profile.p_id).map(function (p) {
      p.LikedProfiles = []
      return p
    })

    dispatch({
      type: 'getAllPostsViews'
    })
    dispatch({
      type: 'getAllPostsLikes'
    })
    dispatch({
      type: 'getAllPostsComments'
    })
  })
}
export const getAllPostsLikes = function ({
  commit,
  state
}, successCallback) {
  restService.GET('post_like', { pageSize: 100000 }, function (res) {
    console.log(res.data.Document.records)
    let likes = res.data.Document.records
    state.allPosts = state.allPosts.map(function (p) {
      p.LikedProfiles = []
      for (let i = 0; i < likes.length; i++) {
        if (likes[i].fk_post === p.post_id) {
          p.LikedProfiles.push(likes[i].fk_profile)
        }
      }
      return p
    })
  })
}
export const getAllPostsViews = function ({
  commit,
  state
}, successCallback) {
  restService.GET('post_view', {}, function (res) {
    console.log(res.data.Document.records)
    let views = res.data.Document.records
    state.allPosts = state.allPosts.map(function (p) {
      p.ViewedProfiles = 1
      for (let i = 0; i < views.length; i++) {
        if (views[i].fk_post === p.post_id) {
          p.ViewedProfiles = views[i].views
        }
      }
      return p
    })
  })
}
export const getAllPostsComments = function ({
  commit,
  state
}, successCallback) {
  restService.GET('post_comment', {pageSize: 100000}, function (res) {
    console.log(res.data.Document.records)
    let allComments = res.data.Document.records
    state.allPosts = state.allPosts.map(function (p) {
      p.comments = []
      for (let i = 0; i < allComments.length; i++) {
        if (allComments[i].fk_post === p.post_id) {
          p.comments.push({
            fk_profile: allComments[i].fk_profile,
            comment: allComments[i].co_comment
          })
        }
      }
      return p
    })
  })
}

export const getNewPosts = function ({
  commit,
  state
}, payload) {
  restService.GET('post', {
    sinceDateTime: state.receivedLastPostsOn.format('YYYY-MM-DD HH:mm:ss')
  }, function (res) {
    console.log(res.data.Document)
    if (res.data.Document.length > 0) {
      let curr = state.allPosts
      let newLst = _.concat(res.data.Document, curr)
      state.allPosts = newLst
      state.receivedLastPostsOn = new moment()
      state.myPosts = state.allPosts.filter(p => p.fk_profile == state.profile.p_id)
    }
    payload.successCB()
  }, function () {
    payload.errorCB()
  })
}

export const postLocation = function ({
  commit,
  state
}, payload) {
  restService.POST('location', payload.location, function (res) {
    commit(mutationTypes.UPDATE_PROFILE, payload.location)
    commit(mutationTypes.UPDATE_PROFILE, {
      fk_location: res.data.Document,
      lo_id: res.data.Document,
    })
    payload.successCB(res)
  })
}

export const putLocation = function ({
  commit,
  state
}, payload) {
  restService.PUT('location/' + payload.location.lo_id, payload.location, function (res) {
    commit(mutationTypes.UPDATE_PROFILE, payload.location)
    payload.successCB(res)
  })
}

export const unfollow = function ({
  commit,
  state
}, payload) {
  restService.DELETE(`profile_follow/${state.profile.p_id}/${payload.following}`, undefined, function (res) {
    console.log(res)
    let fNew = state.profile.Followings.split(',').filter(t => t != payload.following).join(',')
    commit(mutationTypes.UPDATE_PROFILE, {
      Followings: fNew
    })
    payload.successCB(res)
  })
}

export const follow = function ({
  commit,
  state
}, payload) {
  restService.POST('profile_follow', {
    fk_following_profile: state.profile.p_id,
    fk_followed_profile: payload.following,
    fo_getnotified: 1
  }, function (res) {
    let fNew = state.profile.Followings.split(',')
    fNew.push(payload.following)
    fNew = fNew.join(',')
    commit(mutationTypes.UPDATE_PROFILE, {
      Followings: fNew
    })
    payload.successCB(res)
  })
}

export const deleteLocation = function ({
  commit,
  state
}, payload) {
  restService.DELETE('location/' + payload.location.lo_id, payload.location, function (res) {
    commit(mutationTypes.UPDATE_PROFILE, {
      lo_id: null,
      fk_location: null
    })
    payload.successCB(res)
  })
}

export const viewMessage = function ({
  commit,
  state
}, payload) {
  restService.PUT('private_message/' + payload.message.pm_id + '/viewed', {}, function (res) {
    let msgs = state.allMessages
    for (const [key, value] of Object.entries(msgs)) {
      console.log(`${key}: ${value}`);
      msgs[key] = value.map(function (msg) {
        if (msg.pm_id === payload.message.pm_id) {
          msg.pm_viewed = 1
        }
        return msg
      })
    }
    state.allMessages = msgs
  })
}

export const viewNotification = function ({
  commit,
  state
}, payload) {
  restService.PUT('notification/' + payload.notification.noti_id + '/viewed', {}, function (res) {
    let notificationLst = state.notifications
    for (let i = 0; i < notificationLst.length; i++) {
      if (notificationLst[i].noti_id === payload.notification.noti_id) {
        notificationLst[i].noti_viewed = 1
      }
    }
    state.notifications = notificationLst
  })
}

export const putProfile = function ({
  commit,
  state
}, payload) {
  let successCB = payload.successCB
  restService.PUT('profile/' + payload.profile.p_id, payload.profile, function (res) {
    commit(mutationTypes.UPDATE_PROFILE, payload.profile)
    if (window.plugins && window.plugins.OneSignal && window.plugins.OneSignal.sendTags) {
      window.plugins.OneSignal.sendTags({
        userid: state.profile.u_id,
        tags: state.profile.ProfileTags,
        username: state.profile.p_username,
        gsm: state.profile.p_telephone,
        photo: state.profile.p_photo,
        mail: state.profile.u_mail,
        profileid: state.profile.p_id
      })
    }
    successCB(res)
  })
}

export const getAllNotifications = function ({
  commit,
  state
}, payload) {
  console.log('---------------------------------')
  console.log(state.profile.p_id)
  restService.GET('notification', {
    fk_for_profile: state.profile.p_id
  }, function (res) {
    state.notifications = res.data.Document.records
    if (payload && payload.cbFunction) {
      payload.cbFunction()
    }
  })
}

export const getAllMessages = function ({
  commit,
  state
}, successCallback) {
  console.log('---------------------------------')
  console.log(state.profile.p_id)
  restService.GET('private_message', {
    toProfile: state.profile.p_id
  }, function (res) {
    console.log(res)
    let msgs = res.data.Document.records
    let groups = {}
    function addMsgToGroups(profile, msg) {
      if (!groups[profile]) {
        groups[profile] = []
      }
      groups[profile].push(msg)
    }
    for (let i = 0; i < msgs.length; i++) {
      if (msgs[i].fk_from_profile === state.profile.p_id) {
        console.log('add to' + msgs[i].fk_to_profile)
        msgs[i].pm_viewed = 1
        addMsgToGroups(msgs[i].fk_to_profile, msgs[i])
      } else {
        console.log('add to' + msgs[i].fk_from_profile)
        addMsgToGroups(msgs[i].fk_from_profile, msgs[i])
      }
    }
    state.allMessages = groups
  })
}

export const getAnswers = function ({
  commit,
  state
}, payload) {
  restService.GET(`post_answer/${payload.postID}`, {}, function (res) {
    console.log(res)
    payload.successCB(res.data.Document)
  }, () => { }, false)
}

export const getChoices = function ({
  commit,
  state
}, payload) {
  restService.GET(`post_choice/${payload.postID}`, {}, function (res) {
    console.log(res)
    payload.successCB(res.data.Document)
  }, () => { }, false)
}

export const getAllCategories = function ({
  commit,
  state
}, successCallback) {
  if (state.categories.length === 0) {
    restService.GET('category', {}, function (res) {
      console.log(res)
      state.categories = res.data.Document.records
    })
  }
}
export const getAllTags = function ({
  commit,
  state
}, successCallback) {
  if (state.tags.length === 0) {
    restService.GET('tag', {}, function (res) {
      console.log(res);
      let tags = res.data.Document.records
      state.tags = res.data.Document.records
      let cats = []
      for (let i = 0; i < tags.length; i++) {
        let toBeInsertedItem = tags[i]
        if (cats.filter(c => c.ca_id === toBeInsertedItem.ca_id).length === 0) {
          toBeInsertedItem.id = toBeInsertedItem.ca_icon + ' ca-id-' + toBeInsertedItem.ca_id
          toBeInsertedItem.label = toBeInsertedItem['ca_name_' + state.lang]
          toBeInsertedItem.children = []
          cats.push(toBeInsertedItem)
        }
        cats.map(function (c) {
          if (c.ca_id === toBeInsertedItem.ca_id) {
            toBeInsertedItem = _.clone(toBeInsertedItem)
            toBeInsertedItem.id = toBeInsertedItem.tag_icon + ' tag-id-' + toBeInsertedItem.tag_id
            toBeInsertedItem.label = toBeInsertedItem['tag_name_' + state.lang]
            delete toBeInsertedItem.children
            c.children.push(toBeInsertedItem)
          }
          return c
        })
      }
      state.searchCatsAndTags = cats
    })
  }
}


export const getAllProvincesAndTowns = function ({
  commit,
  state
}, successCallback) {
  let result = []
  restService.GET('province', {}, function (proRes) {
    state.provinces = proRes.data.Document.records.map(function (pr) {
      pr.id = pr.pr_id
      pr.label = pr['pr_name_' + state.lang]
      return pr
    })
    restService.GET('town', {}, function (townRes) {
      let towns = _.cloneDeep(townRes.data.Document.records)
      state.towns = townRes.data.Document.records.map(function (twn) {
        twn.id = twn.town_id
        twn.label = twn['town_name_' + state.lang]
        return twn
      })
      for (let i = 0; i < towns.length; i++) {
        let toBeInsertedItem = towns[i]
        if (result.filter(r => r.pr_id === toBeInsertedItem.pr_id).length === 0) {
          toBeInsertedItem.id = 'prov-' + toBeInsertedItem.pr_id
          toBeInsertedItem.label = toBeInsertedItem['pr_name_' + state.lang]
          toBeInsertedItem.children = []
          result.push(toBeInsertedItem)
        }
        result.map(function (r) {
          if (r.pr_id === toBeInsertedItem.pr_id) {
            toBeInsertedItem = _.clone(toBeInsertedItem)
            toBeInsertedItem.id = 'town-' + toBeInsertedItem.town_id
            toBeInsertedItem.label = toBeInsertedItem['town_name_' + state.lang]
            delete toBeInsertedItem.children
            r.children.push(toBeInsertedItem)
          }
          return r
        })
      }
    })
  })
  state.searchProvAndTowns = result
}

export const ping = function ({
  commit,
  state
}, successCallback) {

  var restService = new RS.default() //eslint-disable-line
  console.log(successCallback)
  restService.GET('servertypeinfo', {}, successCallback)
}

export const logoutProcedureForApp = function ({
  dispatch,
  state,
  commit
}, params) {
  commit(mutationTypes.SET_STATE_TO_INITIAL_VALUES)
  commit(mutationTypes.LOGGED_OUT_ONCE)
  commit(mutationTypes.SHOW_MESSAGE, 'Je bent afgemeld')
  router.push('/')
}

export const logout = function ({
  dispatch,
  state,
  commit
},
  params) {
  var logoutRequest = {
    'action': 'WisaUserAPI',
    'method': 'Logout',
    'data': [],
    'type': 'rpc',
    'tid': '1'
  }

  var restService = new RS.default() //eslint-disable-line
  restService.POST(
    'RPC/ROUTER',
    logoutRequest,
    function () {
      dispatch('logoutProcedureForModuleStates')
      dispatch('logoutProcedureForApp')
    },
    function (resultRouter) {
      commit(mutationTypes.SHOW_MESSAGE, ['Fout : ' + resultRouter.error, 'error'])
      dispatch('logoutProcedureForModuleStates')
      dispatch('logoutProcedureForApp')
    },
    true,
    0,
    ''
  )
}




export const postNewProfileTags = function ({
  dispatch,
  state,
  commit
}, params) {
  let requests = []
  let tagIds = params.tagIds
  for (let i = 0; i < tagIds.length; i++) {
    requests.push({
      resource: 'profile_tags',
      parameters: {
        fk_profile: state.profile.p_id,
        fk_tag: tagIds[i]
      }
    })
  }
  restService.DELETE('profile_tags/' + state.profile.p_id, {}, function () {
    restService.EXECUTE_CONCURRENT(
      'POST',
      requests,
      function (res) {
        commit(mutationTypes.UPDATE_PROFILE, {
          ProfileTags: params.tagIds.join(',')
        })
        params.successCB()
      }
    )
  })
}

export const deletePost = function ({
  dispatch,
  state,
  commit
}, params) {
  restService.DELETE('post/' + params.postID, {}, function () {
    state.allPosts = state.allPosts.filter(p => p.post_id != params.postID)
    state.myPosts = state.allPosts.filter(p => p.fk_profile == state.profile.p_id)
    params.successCB()
  })
}


export const postChoices = function ({
  dispatch,
  state
}, params) {
  let requests = []
  let choices = params.choices
  for (let i = 0; i < choices.length; i++) {
    requests.push({
      resource: 'post_choice',
      parameters: {
        fk_post: params.postID,
        pcho_answer: choices[i].optionName
      }
    })
  }
  restService.EXECUTE_CONCURRENT(
    'POST',
    requests,
    function (res) {
      params.successCallback()
    }
  )
}


export const postPostTags = function ({
  dispatch,
  state
}, params) {
  console.log(state.profile.ProfileTags)
  let requests = []
  if (state.profile.ProfileTags !== null && state.profile.ProfileTags.length > 0) {
    let profileTags = state.profile.ProfileTags.split(',')
    for (let i = 0; i < profileTags.length; i++) {
      requests.push({
        resource: 'post_tags',
        parameters: {
          fk_post: params.postID,
          fk_tag: profileTags[i]
        }
      })
    }
  } else {
    requests = [{
      resource: 'post_tags',
      parameters: {
        fk_post: params.postID,
        fk_tag: 95
      }
    }]
  }
  restService.EXECUTE_CONCURRENT(
    'POST',
    requests,
    function (res) {
      params.successCallback()
    }
  )
}

export const getPersoneelData = function ({
  dispatch,
  state,
  commit,
  rootState
}, dezeDit) {
  var dit = dezeDit
  restService.GET('Personeel', {
    User: rootState.userInfo.loggedInUserInformation.UserData.userid
  },
    function (res) {
      var loggedInUserInformation = rootState.userInfo.loggedInUserInformation
      var personeelData = res.data.data[0]
      loggedInUserInformation.PersoneelData = personeelData
      commit(globalMutationTypes.SET_LOGGED_IN_USER_INFORMATION, loggedInUserInformation)
      dit.$store.dispatch(dit.successcallback, dit)
    },
    function (res) {
      dit.$store.dispatch(dit.failureCallback, dit)
    })
}