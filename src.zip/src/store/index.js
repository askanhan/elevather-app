/* global module */
import Vue from 'vue'
import Vuex from 'vuex'
import * as getters from './getters'
import * as actions from './actions'


import {
  mutations
} from './mutations'

Vue.use(Vuex)
// const debug = process.env.NODE_ENV !== 'production'

var inDebuggingMode = false
var inNewFeaturesMode = false
if (window !== undefined && window.parent !== undefined) {
  if (window.parent.LOGGING !== undefined) {
    inDebuggingMode = window.parent.LOGGING
  }
  if (window.parent.NEW_FEATURES !== undefined) {
    inNewFeaturesMode = window.parent.NEW_FEATURES
  }
}

var isMobile = false
if ($('.on-device')[0] !== undefined) {
  isMobile = true
}


const initialState = {
  lang: 'tr',
  receivedLastPostsOn: '',
  connectedProvince: -1,
  allCatched: false,
  specialButton: {},
  searchProvAndTowns: [],
  adTab: [],
  notifications: [],
  myProvince: '',
  searchCatsAndTags: [],
  headerTitle: {},
  categories: [],
  tags: [],
  allPosts: [],
  allMessages: [],
  allProfiles: [],
  // debugging: inDebuggingMode,
  serverLocation: 'http://173.212.229.149:8448',
  // serverLocation: 'http://kesfet.be/nserver/',
  profile: {},
  user: {},
  token: '',
  towns: [],
  provinces: [],
  flags: {
    loggedIn: false,
    screenDisabled: false,
    screenLocked: false
  },
  myPosts: [],
  showedMessage: '',
  currentDropdownMenu: '',
  activeModule: '',
  menubarItems: {
    left: [],
    title: '',
    right: [],
    rightAsTextButtons: [],
    isRightSideMenuOpen: false,
    rightSideMenuItems: []
  },
  allDropdownMenus: {}, // to be followed structure for its child element:
  /* {
    dropdownID: '', // required
    listOfItems: [], // required
    propertyToBeShown: '', // required
    keepDataAfterSelection:true, // optional
    title: 'Selecteer een vak', // optional
    isMultiSelect: false, // optional
    showFilterBar: false // optional
  } */
  closeDialog: false,
  lastActiveDialog: ''
}
export const state = JSON.parse(JSON.stringify(initialState))
state.initialValues = JSON.parse(JSON.stringify(initialState))

const store = new Vuex.Store({
  state: JSON.parse(JSON.stringify(state)),
  getters,
  actions,
  mutations,
  modules: {
  }
  /* ,strict: debug,
  plugins: debug ? [createLogger()] : [] */
})

if (module.hot) {
  module.hot.accept(
    [
      //  './state',
      './getters',
      './actions',
      './mutations'
    ],
    () => {
      store.hotUpdate({
        // state,
        getters,
        actions,
        mutations,
        modules: {
        }
      })
    }
  )
}

export default store