import * as globalTypes from '@/store/mutation-types'
import icons from '@/mixins/icons.js'
import basicOperations from '@/mixins/basic-operations'
import * as mutationTypes from '@/store/mutation-types.js'

import UIText from '@/mixins/ui-text.js'
//  const basicOperations = require('@/mixins/basic-operations.js')

import Vue from 'vue'
export default {
  name: 'Search',
  mixins: [basicOperations, icons, UIText],
  /* 
    components: {
      UIText
    }, */
  data() {
    return {
      welcomeMessage: '',
    }
  },

  computed: {
    lang() {
      return this.$store.state.lang
    }
  },
  created() {},
  mounted() {},
  methods: {
    goToTagPosts(tagID) {
      console.log('goooooooo')
    }
  },
  watch: {}
}