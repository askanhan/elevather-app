import icons from '@/mixins/icons.js'

export default {
  name: 'Dialog_Component',
  mixins: [icons],
  data () {
    return {
    }
  },

  created () {
  },
  methods: {
  }
}
