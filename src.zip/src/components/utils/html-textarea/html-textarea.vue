<template src="./html-textarea.html"></template>
<script src="./html-textarea.js"></script>
<style src="./html-textarea.css" scoped></style>
