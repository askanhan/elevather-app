import Menubar from '@/components/complementarities/menubar/menubar.vue'
import NavigationBar from '@/components/complementarities/navigation-bar/navigation-bar.vue'
import * as mutationTypes from '@/store/mutation-types.js'
import icons from '@/mixins/icons.js'
import globalMixin from '@/mixins/global.js'

import Vue from 'vue'
Vue.mixin(globalMixin)
export default {
  name: 'app',
  components: {
    Menubar,
    NavigationBar
  },
  mixins: [icons],
  created() {},
  computed: {
    isScreenDisabled() {
      return this.$store.state.flags.screenDisabled
    },
    isScreenLocked() {
      return this.$store.state.flags.screenLocked
    },
    lockedScreenClassIfApplied() {
      let res = this.isDesktopModeOn ? 'desktop-mode-on' : ''
      if (this.$store.state.flags.screenDisabled) {
        // console.log(res + ' disabled-screen')
        return res + ' disabled-screen'
      }
      if (this.$store.state.flags.screenLocked) {
        // console.log(res + ' disabled-screen')
        return res + ' locked-screen'
      }
      return res
    },
    isDesktopModeOn() {
      return false //window.innerWidth > 800 && window.device && window.device.pc
    }
  },
  methods: {
    showMessage() {
      this.$store.commit(mutationTypes.SHOW_MESSAGE, '')
    }
  }
}