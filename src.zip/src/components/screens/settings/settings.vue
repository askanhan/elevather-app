<template src="./settings.html"></template>
<script src="./settings.js"></script>
<style src="./settings.css" scoped></style>
