import * as globalTypes from '@/store/mutation-types'
import Footer from '@/components/complementarities/footer/footer.vue'
import icons from '@/mixins/icons.js'
import basicOperations from '@/mixins/basic-operations'
import * as mutationTypes from '@/store/mutation-types.js'
import UIText from '@/mixins/ui-text.js'
//  const basicOperations = require('@/mixins/basic-operations.js')

import Vue from 'vue'
export default {
  name: 'Login',
  components: {
    Footer
  },
  mixins: [basicOperations, icons, UIText],
  data() {
    return {
      email: '',
      password: ''
    }
  },

  computed: { // cached and changed only if one of its dependencies is changed
  },
  created() {
  },
  mounted() { },
  methods: {
    validateEmail(email) {
      // eslint-disable-next-line 
      let re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
      return re.test(String(email).toLowerCase())
    },
    login() {
      this.$store.dispatch({
        type: 'login',
        email: this.email,
        password: this.password,
        successCB: (res) => {
          this.$router.push({
            name: 'home'
          })
        }
      })
    }
  },
  watch: {}
}