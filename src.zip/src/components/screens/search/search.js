import * as globalTypes from '@/store/mutation-types'
import icons from '@/mixins/icons.js'
import basicOperations from '@/mixins/basic-operations'
import * as mutationTypes from '@/store/mutation-types.js'
import UIText from '@/mixins/ui-text.js'
// import the component
import Treeselect from '@riophae/vue-treeselect'
// import the styles
import '@riophae/vue-treeselect/dist/vue-treeselect.css'
//  const basicOperations = require('@/mixins/basic-operations.js')

import Vue from 'vue'
export default {
  name: 'Search',
  mixins: [basicOperations, icons, UIText],
  components: { Treeselect },
  /* 
    components: {
      UITex t
    }, */
  data() {
    return {
      selectedCatAndTags: null,
      aaa: null,
      selectedProvinceAndCities: null,
      noContentMsg: ''
    }
  },

  computed: {
    allCategories() {
      return this.$store.state.categories
    },
    allTags() {
      return this.$store.state.tags
    },
    searchCatsAndTags() {
      return this.$store.state.searchCatsAndTags
    },
    searchProvAndTowns() {
      return this.$store.state.searchProvAndTowns
    },
    toBeShownProfiles() {
      if ((this.selectedCatAndTags == null || this.selectedCatAndTags == undefined || this.selectedCatAndTags == '')
        &&
        (this.selectedProvinceAndCities == null || this.selectedProvinceAndCities == undefined || this.selectedProvinceAndCities == '')
      ) {
        this.noContentMsg = this.UIText.chooseFilter
        return []
      }
      this.noContentMsg = this.UIText.noProfileFound
      return this.$store.state.allProfiles.filter((p) => {
        if (p.ProfileTags == null) {
          return false
        }
        let tagPositive = false
        let profileTags = this.getProfileTags(p)
        let selection = this.selectedCatAndTags
        if (selection && selection.length > 0) {
          let isCat = selection.indexOf('ca-id-') !== -1
          if (isCat) {
            let catID = selection.split('ca-id-')[1]
            if (profileTags.filter(pt => pt.ca_id == catID).length > 0) {
              tagPositive = true
            }
          } else {
            let tagID = selection.split('tag-id-')[1]
            if (profileTags.filter(pt => pt.tag_id == tagID).length > 0) {
              tagPositive = true
            }
          }
        } else {
          tagPositive = true
        }
        let locationPositive = false
        let pTown = this.$store.getters.getTown(p.fk_town).town_id
        let pProv = this.$store.getters.getProvince(p.fk_province).pr_id
        selection = this.selectedProvinceAndCities
        if (selection && selection.length > 0) {
          let isProv = selection.indexOf('prov-') !== -1
          if (isProv) {
            let provID = selection.split('prov-')[1]
            if (pProv == provID) {
              locationPositive = true
            }
          } else {
            let townID = selection.split('town-')[1]
            if (pTown == townID) {
              locationPositive = true
            }
          }
        } else {
          locationPositive = true
        }
        return tagPositive && locationPositive
      })
    }
  },
  created() {
    this.$store.dispatch('getAllCategories');
    this.$store.dispatch('getAllTags');
    this.decryptIfNeeded()
  },
  mounted() { },
  methods: {
    goToProfile(ppID) {
      this.encrypt()
      this.$router.push({
        name: 'profile',
        params: {
          profileID: ppID
        }
      })
    },
    encrypt(){
      sessionStorage.selectedCatAndTags = this.selectedCatAndTags
      sessionStorage.selectedProvinceAndCities = this.selectedProvinceAndCities
    },
    decryptIfNeeded(){
      if(sessionStorage.selectedCatAndTags && sessionStorage.selectedProvinceAndCities){
        this.selectedCatAndTags = (sessionStorage.selectedCatAndTags === "null" || sessionStorage.selectedCatAndTags === "undefined") ? null : sessionStorage.selectedCatAndTags
        this.selectedProvinceAndCities = (sessionStorage.selectedProvinceAndCities === "null" || sessionStorage.selectedProvinceAndCities === "undefined") ? null : sessionStorage.selectedProvinceAndCities
        delete sessionStorage.selectedCatAndTags
        delete sessionStorage.selectedProvinceAndCities
      }
    },
    getProfileTags(profile) {
      console.log(profile.ProfileTags)
      return _.intersectionWith(this.$store.state.tags, profile.ProfileTags.split(','), (a, b) => a.tag_id == b)
    },
    goToTagPosts(catID, tagID) {
      this.$router.push({
        name: 'PostList',
        params: {
          screen: 'search',
          catID,
          tagID
        }
      })
    }
  },
  watch: {}
}