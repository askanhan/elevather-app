<template src="./splash-screen.html"></template>
<script src="./splash-screen.js"></script>
<style src="./splash-screen.css" scoped></style>
