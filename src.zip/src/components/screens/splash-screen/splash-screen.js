import * as globalTypes from '@/store/mutation-types'
import Footer from '@/components/complementarities/footer/footer.vue'
import icons from '@/mixins/icons.js'
import basicOperations from '@/mixins/basic-operations'
import * as mutationTypes from '@/store/mutation-types.js'
import UIText from '@/mixins/ui-text.js'
//  const basicOperations = require('@/mixins/basic-operations.js')

import Vue from 'vue'

export default {
  name: 'SplashScreen',
  mixins: [basicOperations, icons, UIText],
  data() {
    return {
      selectedLanguage: 'tr',
      swiperReady: false,
      activeIdx: 0,
      splashSwipeOptions: {
        pagination: {
          el: '.swiper-pagination',
          clickable: true
        },
        speed: 300,
        slidesPerView: 1,
      },
    }
  },

  computed: { // cached and changed only if one of its dependencies is changed
    swiper() {
      return this.$refs.mySwiper ? this.$refs.mySwiper.$swiper : { activeIndex: -1 }
    },
    lang(){
      return this.$store.state.lang
    }
  },
  created() {
    this.detectLang()
    this.detectLocation()
  },
  mounted() {
    // if already saved login available -> login
    localforage.getItem('username').then(un => {
      console.log(un)
      localforage.getItem('password').then(pwd => {
        console.log(pwd)
        if (un !== null && pwd !== null) {
          this.$store.dispatch({
            type: 'login',
            email: un,
            password: pwd,
            successCB: (res) => {
              this.$router.push({
                name: 'home'
              })
            }
          })
        }
      })
    })
  },
  methods: {
    detectLocation(){
      this._detectLocation((connectedProvince) => {
        this.$store.commit('SET_CONNECTED_PROVINCE', connectedProvince)
      })
    },
    handleClickSlide() {
      this.activeIdx = this.$refs.mySwiper.$swiper.activeIndex
    },
    handleSwiperReadied() {
      this.swiperReady = true
    },
    goToRegister() {
      this.$router.push({
        name: 'register'
      })
    },
    openLangModal(){
      this.$modal.show('threedot')
    },
    detectLang() {
      localforage.getItem('lang', (err, lang) => {
        console.log(err)
        console.log(lang)
        if(lang == null){
          console.log('no language ...')
          console.log('assigning language ...')
          if (navigator.language) {
            if (navigator.language.indexOf('nl')) {
              this._setLanguageOfApp('nl')
            } else if (navigator.language.indexOf('fr')) {
              this._setLanguageOfApp('fr')
            } else {
              this._setLanguageOfApp('tr')
            }
          }else {
            this._setLanguageOfApp('tr')
          }
        }else{
          this._setLanguageOfApp(lang)
        }
      })
    },
    setLang(lang) {
      this.$store.commit(mutationTypes.SET_LANG, lang)
      this.selectedLanguage = lang
    },
    changeToLoginMode() {
      this.mode = 'login'
      this.name = ''
      this.password = ''
      this.email = ''
    },
    changeToRegisterMode() {
      this.mode = 'register'
      this.name = ''
      this.password = ''
      this.email = ''
    },
    languageChanged() {
      this.$store.commit(mutationTypes.CHANGE_LANGUAGE, this.selectedLanguage)
    },
  },
  watch: {}
}