<template src="./select-tag.html"></template>
<script src="./select-tag.js"></script>
<style src="./select-tag.css" scoped></style>
