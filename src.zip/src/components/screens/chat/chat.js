import * as globalTypes from '@/store/mutation-types'
import icons from '@/mixins/icons.js'
import basicOperations from '@/mixins/basic-operations'
import * as mutationTypes from '@/store/mutation-types.js'
import VueScrollTo from 'vue-scrollto'
import { TYPE } from "vue-toastification"
import UIText from '@/mixins/ui-text.js'

//  const basicOperations = require('@/mixins/basic-operations.js')

import Vue from 'vue'
export default {
  name: 'chat',
  mixins: [basicOperations, icons, UIText],
  data() {
    return {
      messages: [],
      toBeSentMessage: ''
    }
  },

  computed: {
    lang() {
      return this.$store.state.lang
    }
  },
  created() {
    this.messages = JSON.parse(JSON.stringify(this.$route.params.chat))
    this.viewUnviewedMessages()
  },
  mounted() {
    setTimeout(() => {
      this.goToEnd()
    }, 500)
  },
  methods: {
    getProfile(id) {
      return this.$store.getters.getProfile(id)
    },
    viewUnviewedMessages() {
      for (let i = 0; i < this.messages.length; i++) {
        if (this.messages[i].pm_viewed == 0 && this.messages[i].fk_from_profile != this.$store.state.profile.p_id) {
          console.log('View:')
          console.log(this.messages[i])
          this.$store.dispatch({
            type: 'viewMessage',
            message: this.messages[i]
          })
        }
      }
    },
    goToEnd() {
      console.log(VueScrollTo)
      var options = {
        container: '.page',
        easing: 'ease-in',
        lazy: false,
        offset: -60,
        force: true,
        cancelable: true,
        onStart: function (element) {
          // scrolling started
        },
        onDone: function (element) {
          // scrolling is done
        },
        onCancel: function () {
          // scrolling has been interrupted
        },
        x: false,
        y: true
      }
      console.log(this.$scrollTo)
      this.$scrollTo('#element', 300, options)
    },
    myMessage(msg) {
      return msg.fk_from_profile == this.$store.state.profile.p_id
    },
    getFromNow(msg) {
      if(msg){
        return new moment(msg.pm_date).fromNow()
      }
    },
    sendMessage() {
      if (this.toBeSentMessage.length > 0) {
        if (this.toBeSentMessage.length > 2040) {
          this.$toast(this.UIText.tooLong, {
            type: TYPE.ERROR
          });
        } else {
          console.log('send: ' + this.toBeSentMessage)
          let toBeSentObject = {
            fk_from_profile: this.$store.state.profile.p_id,
            fk_to_profile: this.$route.params.profile.p_id,
            pm_content: this.toBeSentMessage,
            pm_type: 0,
            pm_viewed: 0
          }

          this.$store.dispatch({
            type: 'postMessage',
            toBeSentObject,
            successCB: () => {
              toBeSentObject.pm_date = new moment().toISOString()
              toBeSentObject.pm_viewed = 1
              this.messages.push(toBeSentObject)
              this.toBeSentMessage = ''
              this.goToEnd()
            }
          })
        }
      }
    }
  },
  watch: {}
}