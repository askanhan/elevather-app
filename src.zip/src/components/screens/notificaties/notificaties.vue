<template src="./notificaties.html"></template>
<script src="./notificaties.js"></script>
<style src="./notificaties.css" scoped></style>
