/*, n
Select kids if the logged in parent has more than one -active- children
Otherwise, the only possible child will be selected.
After one of these two scenarios, it will be redirected to "agenda" page.
 */
import * as mutationTypes from '@/store/mutation-types.js'
import Post from '@/components/complementarities/post/post.vue'
import _ from 'lodash'

export default {
  name: 'notificaties',
  components: {
    Post
  },
  data() {
    return {
      notificaties: [],
      // type: {
      //   1: postLiked,
      //   2: postCommented,
      //   3: startedFollowing,
      // }
    }
  },

  created() {
    this.$store.commit('SET_HEADER_TITLE', {
      tr: 'Bildirimlerim',
      nl: 'Mijn notificaties',
      fr: 'Mes notifications'
    })
    this.$store.dispatch({
      type: 'getAllNotifications',
      cbFunction: (res) => {
        this.viewAllNotificationsIfAny()
      }
    })
  },
  computed: {
    lang() {
      return this.$store.state.lang
    },
    notifications() {
      return this.$store.state.notifications
    }
  },
  methods: {
    goToPost(postID){
      this.$router.push({
        name: 'postcontainer',
        params: {
          postID: postID
        }
      })
    },
    goToProfile(ppID) {
      this.$router.push({
        name: 'profile',
        params: {
          profileID: ppID
        }
      })
    },
    viewAllNotificationsIfAny(){
      for (let i = 0; i < this.notifications.length; i++) {
        if (this.notifications[i].noti_viewed == 0) {
          this.$store.dispatch({
            type: 'viewNotification',
            notification: this.notifications[i]
          })
        }
      }
    },
    getFromNow(dt) {
      return new moment(dt).fromNow()
    },
    getProfile(id) {
      return this.$store.getters.getProfile(id).p_username
    },
    getPost(id) {
      return this.$store.getters.getPost(id)
    },

  }
}