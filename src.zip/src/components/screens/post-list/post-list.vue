<template src="./post-list.html"></template>
<script src="./post-list.js"></script>
<style src="./post-list.css" scoped></style>
