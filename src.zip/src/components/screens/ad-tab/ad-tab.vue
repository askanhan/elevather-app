<template src="./ad-tab.html"></template>
<script src="./ad-tab.js"></script>
<style src="./ad-tab.css" scoped></style>
