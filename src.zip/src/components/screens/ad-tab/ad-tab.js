import * as globalTypes from '@/store/mutation-types'
import icons from '@/mixins/icons.js'
import Post from '@/components/complementarities/post/post.vue'
import basicOperations from '@/mixins/basic-operations'
import * as mutationTypes from '@/store/mutation-types.js'
import UIText from '@/mixins/ui-text.js'
import Footer from '@/components/complementarities/footer/footer.vue'
//  const basicOperations = require('@/mixins/basic-operations.js')

import Vue from 'vue'
export default {
  name: 'AdTab',
  mixins: [basicOperations, icons, UIText],
  components: {
    Post,
    Footer
  },
  data() {
    return {
      selectedProvince: 2
    }
  },

  computed: {
    provinces() {
      return _.sortBy(this.$store.state.provinces, (a) => {
        if (a.pr_id === this.connectedProvince) {
          return 0
        }
        let sortExtra = this.ads.filter(ad => ad.ad_show === 1 && ad.fk_province == a.pr_id).length > 0 ? 30 : 0
        return a.pr_sort - sortExtra
        
        // return this.ads.filter(ad => ad.ad_show === 1 && ad.fk_province == pr.pr_id).length>0
      })
    },
    ads() {
      return this.$store.state.adTab
    },
    connectedProvince() {
      return this.$store.state.connectedProvince
    },
    selectedAd() {
      return this.ads.filter(a => a.fk_province === this.selectedProvince)[0]
    },
    selectedAdsProfile() {
      return this.$store.getters.getProfile(this.selectedAd.fk_profile)
    },
    selectedAdsPost() {
      if (this.selectedAd.fk_post) {
        return this.$store.state.allPosts.filter(p => p.post_id == this.selectedAd.fk_post)
      }
      return null
    },
    slogan1() {
      if (this.selectedAd.ad_slogan_1 !== null && this.selectedAd.ad_slogan_1.length > 0) {
        return this.selectedAd.ad_slogan_1
      }
      return this.selectedAdsProfile.p_username
    },
    slogan2() {
      if (this.selectedAd.ad_slogan_2 !== null && this.selectedAd.ad_slogan_2.length > 0) {
        return this.selectedAd.ad_slogan_2
      }
      return this.selectedAdsProfile.p_bio
    },
  },
  created() {
    this.$store.commit('SET_SPECIAL_BUTTON', {
      label: this.UIText.goForAd[this.lang],
      toBeExecutedFunction: () => {
        this.openForm()
      }
    })
    // if (this.connectedProvince === -1) {
    //   this._detectLocation((connectedProvince) => {
    //     console.log(connectedProvince)
    //     this.selectedProvince = connectedProvince
    //     this.$store.commit('SET_CONNECTED_PROVINCE', connectedProvince)
    //   })
    // } else {
    //   this.selectedProvince = this.connectedProvince
    // }
  },
  mounted() {
  },
  methods: {
    goToProfile(ppID) {
      this.$router.push({
        name: 'profile',
        params: {
          profileID: ppID
        }
      })
    },
    amIFollowing() {
      if (this.$store.state.profile.Followings && this.$store.state.profile.Followings.length > 0) {
        return this.$store.state.profile.Followings.split(',').filter(pid => pid == this.selectedAdsProfile.p_id).length > 0
      }
      return false
    },
    follow(followWithNotification) {
      if (this.amIFollowing()) {
        this.$store.dispatch({
          type: 'unfollow',
          following: this.selectedAdsProfile.p_id,
          successCB: (res) => {

          }
        })
      } else {
        this.$store.dispatch({
          type: 'follow',
          followed: this.$store.state.user.fk_profile,
          following: this.selectedAdsProfile.p_id,
          followWithNotification: 1,
          successCB: (res) => {
            this.$store.dispatch({
              type: 'createNotification',
              noti_type: 3,
              fk_for_profile: this.selectedAdsProfile.fk_profile
            })
          }
        })
      }
    },
    openForm(){
      this.$fire({
        title: this.UIText.adGivenHeader[this.lang],
        text: this.UIText.adOk[this.lang],
        confirmButtonText: this.UIText.okay[this.lang]
      }).then(r => {
        this.$router.go(-1)
        this.$toast(this.UIText.postIsSent[this.lang])
      });
      this.$store.dispatch({
        type: 'postQuestion',
        qu_type: 9,
        message: 'reklam vermek istiyorum (ilk) ' + this.selectedProvince,
        successCallback: () => {
        }
      })
    },
    openAdDialog() {
      this.$fire({
        title: this.UIText.giveAddTitle[this.lang],
        // text: 'selam',
        confirmButtonText: this.UIText.confirm[this.lang]
      }).then(r => {
        console.log(r.value)
        if (r.value) {
          this.$store.dispatch({
            type: 'postQuestion',
            qu_type: 9,
            message: 'reklam vermek istiyorum (ilk) ' + this.selectedProvince,
            successCallback: () => {
              this.$toast(this.UIText.postIsSent[this.lang])
            }
          })
        }
      });
    },
    selectTag() {

    },
    getPostByID(id) {
      return this.$store.state.allPosts.filter(p => p.post_id === id)[0]
    }
  },
  watch: {}
}