<template src="./register.html"></template>
<script src="./register.js"></script>
<style src="./register.css" scoped></style>
