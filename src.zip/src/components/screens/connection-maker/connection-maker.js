import * as globalTypes from '@/store/mutation-types.js'
import DropdownInPlace from '@/components/utils/dropdown-in-place/dropdown-in-place.vue'
import ValidationService from '@/services/validation.service.js'
import icons from '@/mixins/icons.js'
import basicOperations from '@/mixins/basic-operations.js'

const validationService = new ValidationService()

export default {
  name: 'connectionMaker',
  components: {
    DropdownInPlace
  },
  mixins: [icons, basicOperations],
  data () {
    let self = this
    return {
      editMode: false,
      connectionTypes: JSON.parse(JSON.stringify(self.$store.state.allConnectionTypes)),
      connectionObject: {
        connectionName: '',
        serverLocation: '',
        username: '',
        password: '',
        rememberMe: true,
        ID: ''
      }
    }
  },
  created () {
    let self = this
    if (typeof this.$route.params.id !== 'undefined') {
      this.editMode = true
      this.connectionObject = this.$store.getters.getConnectionWithID(this.$route.params.id)
      this.connectionTypes = this.connectionObject.connectionTypes
      if (!this.connectionObject.rememberMe) {
        this.connectionObject.password = ''
      }else{
        this.connectionObject.password = decodeURIComponent(this.connectionObject.password)
      }
      this.$store.commit(globalTypes.SET_TEXT_BUTTONS_ON_MENUBAR, [{
        text: 'BEWAREN',
        FUNCTIE: self.edit,
        getTextButtonClass: self.getTextButtonClass
      }, {
        text: 'VERWIJDEREN',
        FUNCTIE: self.remove
      }])
    } else {
      this.$store.commit(globalTypes.SET_TEXT_BUTTONS_ON_MENUBAR, [{
        text: 'BEWAREN',
        FUNCTIE: self.add,
        getTextButtonClass: self.getTextButtonClass()
      }])
    }
  },
  methods: {
    getTextButtonClass () {
      if (this.isFormValid()) {
        return 'valid'
      }
      return 'non-valid'
    },
    pasteSelectedConnectionTypeToConnectionObject () {
      this.connectionObject.connectionType = this.connectionTypes.filter(function (ct) {
        return ct._selected
      })[0]
      this.connectionObject.password = encodeURIComponent(this.connectionObject.password)
    },
    add () {
      if (this.isFormValid()) {
        this.pasteSelectedConnectionTypeToConnectionObject()
        this.$store.commit(globalTypes.ADD_CONNECTION_TO_LIST_OF_CONNECTIONS, this)
        this.$store.commit(globalTypes.SHOW_MESSAGE, 'Connectie is toegevoegd')
        this._goBack()
      } else {
        this.showFormErrorMessage()
      }
    },
    edit () {
      if (this.isFormValid()) {
        this.pasteSelectedConnectionTypeToConnectionObject()
        this.$store.commit(globalTypes.EDIT_CONNECTION_IN_LIST_OF_CONNECTIONS, this)
        this.$store.commit(globalTypes.SHOW_MESSAGE, 'Connectie is bijgewerkt')
        this._goBack()
      } else {
        this.showFormErrorMessage()
      }
    },
    showFormErrorMessage () {
      let err1 = validationService.isConnectionName(this.connectionObject.connectionName)[1]
      let err2 = validationService.isServerLocation(this.connectionObject.serverLocation)[1]
      let err3 = validationService.isUsername(this.connectionObject.username)[1]
      let err4 = validationService.isPassword(this.connectionObject.password)[1]

      if (err1.length > 0) {
        this.$store.commit(globalTypes.SHOW_MESSAGE, err1)
      } else if (err2.length > 0) {
        this.$store.commit(globalTypes.SHOW_MESSAGE, err2)
      } else if (err3.length > 0) {
        this.$store.commit(globalTypes.SHOW_MESSAGE, err3)
      } else if (err4.length > 0) {
        this.$store.commit(globalTypes.SHOW_MESSAGE, err4)
      }
    },
    remove () {
      this.$store.commit(globalTypes.DELETE_CONNECTION_FROM_LIST_OF_CONNECTIONS, this)
      this.$store.commit(globalTypes.SHOW_MESSAGE, 'Connectie is verwijderd')
      this._goBack()
    },
    goBackToConnectionLists () {
      delete this.connectionObject.connectionTypes
      this._goBack()
    },
    isFormValid () {
      return validationService.isConnectionName(this.connectionObject.connectionName)[0] &&
        validationService.isUsername(this.connectionObject.username)[0] &&
        validationService.isServerLocation(this.connectionObject.serverLocation)[0] &&
        (!this.connectionObject.rememberMe || validationService.isPassword(this.connectionObject.password)[0])
    }
  },
  computed: {

  }
}
