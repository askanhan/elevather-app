import * as globalTypes from '@/store/mutation-types'
import icons from '@/mixins/icons.js'
import basicOperations from '@/mixins/basic-operations'
import * as mutationTypes from '@/store/mutation-types.js'
import Post from '@/components/complementarities/post/post.vue'
import VideoPlayer from '@/components/complementarities/video-player/video-player.vue'
import VueScrollTo from 'vue-scrollto'
import UIText from '@/mixins/ui-text.js'
//  const basicOperations = require('@/mixins/basic-operations.js')
import Vue from 'vue'
export default {
  name: 'Home',
  mixins: [basicOperations, icons, UIText],
  components: {
    Post,
    VideoPlayer
  },
  data() {
    return {
      filterByCat: '',
      loadUntilThisOne: 20,
      loading: false
    }
  },

  computed: { // cached and changed only if one of its dependencies is changed
    myVideo() {
      return document.getElementById("introv")
    },
    homePosts() {
      let posts = this.$store.state.allPosts
      if (localStorage.blockedUsers && localStorage.blockedUsers.length > 0) {
        posts = posts.filter(p => localStorage.blockedUsers.split(',').filter(blockedUser => blockedUser == p.fk_profile).length === 0)
      }
      if (this.filterByCat == '') {
        return posts.slice(0, this.loadUntilThisOne)
      } else if (this.filterByCat == 'onlyFollowedProfiles') {
        let self = this
        return posts.filter(function (p) {
          let myFollowings = self.$store.state.profile.Followings.split(',').map(t => parseInt(t))
          return myFollowings.filter(mf => mf == p.fk_profile).length > 0
        }).splice(0, this.loadUntilThisOne)
      } else {
        let tagIds = this.filterByCat.children.map(t => t.tag_id)
        let self = this
        return posts.filter(function (p) {
          let profile = self.$store.getters.getProfile(p.fk_profile)
          let postTags = [95]
          if (profile.ProfileTags && profile.ProfileTags !== null && profile.ProfileTags.length > 0) {
            postTags = self.$store.getters.getProfile(p.fk_profile).ProfileTags.split(',').map(t => parseInt(t))
          }
          return _.intersection(tagIds, postTags).length > 0
        }).splice(0, this.loadUntilThisOne)
        // return posts.filter(p => )
      }
    },
    cats() {
      return this.$store.state.searchCatsAndTags
    },
    lang() {
      return this.$store.state.lang
    },
  },
  created() {
    if (sessionStorage.loadUntilThisOne) {
      this.loadUntilThisOne = parseInt(sessionStorage.loadUntilThisOne)
    }
    if (!this.$store.state.allCatched) {
      this.$store.dispatch('getAllProfiles')
      this.$store.dispatch('getAllPosts')
      this.$store.dispatch('getAllCategories')
      this.$store.dispatch('getAllMessages')
      this.$store.dispatch('getAllNotifications')
      this.$store.dispatch('getAllTags')
      this.$store.dispatch('getAllProvincesAndTowns')
      this.$store.dispatch('getAdTab')
      this.$store.commit('ALL_CATCHED')
    } else {
      this.$store.dispatch({
        type: 'getNewPosts',
        successCB: () => {
        }
      })
    }
  },
  destroyed() {
    sessionStorage.loadUntilThisOne = this.loadUntilThisOne
  },
  mounted() {
    setTimeout(() => {
      this.goBackToPost()
    }, 300)
  },
  methods: {
    visibilityChanged() {
      console.log('loadUntilThisOneloadUntilThisOne')
      console.log(this.loadUntilThisOne)
      this.loadUntilThisOne += 10
    },
    goBackToPost() {
      if (sessionStorage.homeViewingPost) {
        console.log(VueScrollTo)
        var options = {
          container: '.page',
          easing: 'ease-in',
          lazy: false,
          offset: -60,
          force: true,
          cancelable: true,
          onStart: function (element) {
            // scrolling started
          },
          onDone: function (element) {
            // scrolling is done
          },
          onCancel: function () {
            // scrolling has been interrupted
          },
          x: false,
          y: true
        }
        console.log(this.$scrollTo)
        this.$scrollTo(sessionStorage.homeViewingPost, 0, options)
      }
      delete sessionStorage.homeViewingPost
    },
    filterPosts() {

    },
    changeFilterCat(cat) {
      this.filterByCat = cat
      setTimeout(() => {
        this._goToHomeHead()
      }, 300)
    },
    selectTag(tag) {
      this.changeFilterCat(this.$store.getters.getCategory(tag.ca_id))
    },
    playVideo() {
      if (this.myVideo.paused)
        this.myVideo.play();
      else
        this.myVideo.pause();
    }
  },
  watch: {}
}