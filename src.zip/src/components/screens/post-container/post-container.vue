<template src="./post-container.html"></template>
<script src="./post-container.js"></script>
<style src="./post-container.css" scoped></style>
