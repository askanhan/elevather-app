import Post from '@/components/complementarities/post/post.vue'
import UIText from '@/mixins/ui-text.js'
//  const basicOperations = require('@/mixins/basic-operations.js')
import Vue from 'vue'
export default {
  name: 'PostContainer',
  mixins: [UIText],
  components: {
    Post
  },
  data() {
    return {
      filterByCat: ''
    }
  },

  computed: { // cached and changed only if one of its dependencies is changed
    myVideo() {
      return document.getElementById("introv")
    },
    homePosts() {
        return this.$store.state.allPosts.filter(p => p.post_id == this.$route.params.postID)
    },
    lang() {
      return this.$store.state.lang
    },
  },
  created() {
  },
  mounted() {
  },
  methods: {
  },
  watch: {}
}