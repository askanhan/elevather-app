<template src="./video-player.html"></template>
<script src="./video-player.js"></script>
<style src="./video-player.css" scoped></style>
