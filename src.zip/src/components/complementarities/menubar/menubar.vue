<template src="./menubar.html"></template>
<script src="./menubar.js"></script>
<style src="./menubar.css" scoped></style>
