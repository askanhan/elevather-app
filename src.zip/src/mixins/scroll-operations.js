/* global module */
module.exports = {
  methods: {
    _handleScroll(dit) {
      let _body = $('#' + dit.state.centerId)[0]
      let _head = $('#' + dit.state.headId)[0]
      let _left = $('#' + dit.state.leftId)[0]

      if (dit.isTouch) {
        let scrollYStartPos = 0
        let scrollXStartPos = 0

        //* ***************************************** */
        // Fixed left touch scrolling
        //* ***************************************** */

        _left.addEventListener('touchstart', function (event) {
          scrollYStartPos = this.scrollTop + event.touches[0].pageY
        })

        _left.addEventListener('touchmove', function (event) {
          this.scrollTop = scrollYStartPos - event.touches[0].pageY
          _left.scrollTop = this.scrollTop
          _body.scrollTop = this.scrollTop
          event.preventDefault()
        })

        //* ***************************************** */
        // Fixed header touch scrolling
        //* ***************************************** */

        _head.addEventListener('touchstart', function (event) {
          // scrollYStartPos = this.scrollTop + event.touches[0].pageY
          scrollXStartPos = this.scrollLeft + event.touches[0].pageX
        })

        _head.addEventListener('touchmove', function (event) {
          /* this.scrollTop = scrollYStartPos - event.touches[0].pageY
          _left.scrollTop = this.scrollTop
          _body.scrollTop = this.scrollTop */
          this.scrollLeft = scrollXStartPos - event.touches[0].pageX
          _head.scrollLeft = this.scrollLeft
          _body.scrollLeft = this.scrollLeft
          event.preventDefault()
        })

        //* ***************************************** */
        // Center touch scrolling:
        //* ***************************************** */

        _body.addEventListener('touchstart', function (event) {
          scrollYStartPos = this.scrollTop + event.touches[0].pageY
          scrollXStartPos = this.scrollLeft + event.touches[0].pageX
        })

        _body.addEventListener('touchmove', function (event) {
          this.scrollTop = scrollYStartPos - event.touches[0].pageY
          _left.scrollTop = this.scrollTop
          this.scrollLeft = scrollXStartPos - event.touches[0].pageX
          _head.scrollLeft = this.scrollLeft
          event.preventDefault()
        })
      } else {
        // Fixed left scrolling => center ook scrollen:
        _left.addEventListener('scroll', function () {
          if (_body === null || _body === undefined) {
            _body = $('#' + dit.centerId)[0]
          }
          _body.scrollTop = this.scrollTop
        }, {
          capture: true,
          passive: true
        })

        // Center grid scrolling => left en header scrollen:
        _body.addEventListener('scroll', function () {
          if (_left === null || _left === undefined) {
            _left = $('#' + dit.leftId)[0]
          }
          _left.scrollTop = this.scrollTop

          if (_head === null || _head === undefined) {
            _head = $('#' + dit.headId)[0]
          }
          _head.scrollLeft = this.scrollLeft
        }, {
          capture: true,
          passive: true
        })
      }
    }
  }
}
